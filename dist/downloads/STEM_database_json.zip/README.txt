STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 92b10cf9d83bc5eb2ed37ca338fa8c78a816c1e21975b10c4b4d28aed159cc4d
