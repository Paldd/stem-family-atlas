STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 3e2db14027dee62c976624f917239c52a2ce71246e03fa76e13faa0cd000ca4f
