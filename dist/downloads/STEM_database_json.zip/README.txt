STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 7399d6359c61a35f524351c5464a5a974e0e9202ff43396f073644b2ad0ed027
