STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: d15a4629a8f70f29494163509538961382d72eb13eebd7e2a6e5664eb5bb7b3f
