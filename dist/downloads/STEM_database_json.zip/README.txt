STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: d94e8bf97bc7f8dc6c12d42e3b4e9875b7b1978238d7806ac7271d53a3e58381
