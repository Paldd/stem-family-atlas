STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 15f45c290079eca9f8ad30a9107e6145874226ca301b763eec2fd57060c5eff4
