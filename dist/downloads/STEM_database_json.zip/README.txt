STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 800e185fc24bc103dda42261839d5dac857e7e43c3a5bf010a8a5db29cd92133
