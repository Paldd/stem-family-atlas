STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 74cb379f26c244c4addcf9ba036d9d6f123e06c7fd58ee508f35517c4fc1e281
