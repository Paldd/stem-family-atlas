STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 4914a8366c1d8080652a26ac892912ac792c778dadf67364719a61c54740b35e
