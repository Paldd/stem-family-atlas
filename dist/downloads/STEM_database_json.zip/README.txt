STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: bada32b1138aafa21777a7228011bafb4694aa4797ad1203a676e6ca986f8079
