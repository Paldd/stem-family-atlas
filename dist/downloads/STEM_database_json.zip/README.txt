STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: d53f142d20ecf19f2704d2adfbadbc6d2babfb37d6e2bd942e5da0e4509237d8
