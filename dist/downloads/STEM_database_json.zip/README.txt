STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 8605ca272b8fda6c579e01d145e3b8b338dcf49ea940c89cc1f4b2cd221dbeea
