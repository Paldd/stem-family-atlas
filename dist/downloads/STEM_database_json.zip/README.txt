STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 148e6d3f3b248371d5cd835e8a69ef7e46c7f7330fffa0c51dea3d080afc8178
