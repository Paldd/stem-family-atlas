STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 50549e7a8e0abd44420eee160b535b94615df28d575541fdd552c7b9784a6122
