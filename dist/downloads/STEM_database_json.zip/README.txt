STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: f5a6d0cbfbb0b8204c461f261ee37d5c00fc5e4de3531bbb978ee6d233e30cab
