STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: d86d18b9ada7d573919b46adeae83806e87c317dfad64ee4b783fc720f22f1ed
