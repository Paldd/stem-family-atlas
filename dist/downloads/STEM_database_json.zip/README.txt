STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 51fd0388dcb387c002928f82084e6e1c2608359facf0f8f21398cf2922a29598
