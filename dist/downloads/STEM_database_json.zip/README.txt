STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 4127e2dbcedcd3cae4f689c3da3b9f9b923d10d2fea0dc7063a66a524de8b9c1
