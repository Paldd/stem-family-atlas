STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 48245d328dca353a29a9f05b1a2c59628bf15aba17d0b4bfd130137e4fd14d2f
