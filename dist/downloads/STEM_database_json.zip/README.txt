STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: dccc0bceed7665d5ff3b8e6215a5d85b9b72418832d18b69ce4a090e885d8693
