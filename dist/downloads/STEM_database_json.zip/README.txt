STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 0b0ace608b8ea8f257f38f0a097e090c1bb3a0d329e314c21c0fa3e3eca8571e
