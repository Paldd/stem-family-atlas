STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 42e5ec8c257dc790e8fc4963d6781b1f60c99619c1992da62fe9fa3f69f1b290
