STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 56d5203eafe55bbb27d1a5af064c7321e4d02b84db3dcd076b1889cde3275c1a
