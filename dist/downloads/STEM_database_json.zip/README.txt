STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 16cb5adca7e5db22dde968c499448128066c48e5acfc799e0f3b6cf4d79ca153
