STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 9dbe391d03499b1c418def05111a1d778df1f93e5f8e7ece0871ab4d355fb14d
