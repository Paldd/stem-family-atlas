STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: d708580580eb3813d667440f997dedc1ad2ccd1414d7b56d5d1b1ee1b0c0c4cb
