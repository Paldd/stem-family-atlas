STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 275d21b9a6cefa14949b4ec8064301ba46200ff0a0b4db6aeee0e22b255f5db1
