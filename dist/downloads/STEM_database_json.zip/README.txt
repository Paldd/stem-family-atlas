STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: de3cdf0aa8218aef837c4b00a2b21d93575dbb8a799b5050a99237bb57a0525d
