STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 4ee3c538e7559eb200d8cc69bf885029d1a40547ba8615269ef98ff8d12a3f8b
