STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: acc5a3f69c96ec19d71803728f2a5f3719773d79061ae61a9649cfc004731544
