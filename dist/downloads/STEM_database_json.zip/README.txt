STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 54d8c0a0180c1f5023032fd6faffb547e58d0278609cc131d8950e2e2919ad93
