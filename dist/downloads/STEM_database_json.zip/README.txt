STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: ce139df9b69ae74c5d8e665479260e8850dd83671543eba7090515fb726e83ec
