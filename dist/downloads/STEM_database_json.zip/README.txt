STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 438202df2c3ff672f9bf524a92a5368070a2b4895bb2ab47dc87a5d71adba430
