STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 25ed5debe35f74ae4713a200054269c12838c962cb83f3e81aeafd9709ef23ef
