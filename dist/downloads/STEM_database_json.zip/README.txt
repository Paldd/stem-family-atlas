STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 29a1a9d35b24a550e3379fb55bff9df16206a20b717a1f090ac33401e84ffe47
