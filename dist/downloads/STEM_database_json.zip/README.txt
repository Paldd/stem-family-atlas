STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 5de8dbe93d52bb768a8b608838220da8bd38054abbcdb1260f6168e4ffaa83ed
