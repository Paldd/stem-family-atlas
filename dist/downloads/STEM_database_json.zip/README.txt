STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 6857c39463214e174d960e73b09b91c5259e485edd41732f40a804ce886578e1
