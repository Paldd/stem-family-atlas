STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 4dca09d9742ab3cff91e60d35e0402d636228ba3d961fd3b6d702a37792718e5
