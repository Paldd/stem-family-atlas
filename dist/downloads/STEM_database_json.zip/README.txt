STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 4a96a66186aa8bc39fe9bd59c8bf96a7a81b08f9720e23f1a3d5846da8a3a3dd
