STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 2b2e9c4308b0b881fb49dcce84074822c14f5f2ce10bad1b64f1020b312ea7e7
