STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: d0aab827e224a4e3b6d0af13f1996d391c48ab40973790d65910616e99548c23
