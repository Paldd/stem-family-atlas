STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 1834723bbb3a05969d471d580ae3a6277872b8428d0afd24132b4763e251ebf2
