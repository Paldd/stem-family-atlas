STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 6aeb9c226dc638b9ebd5a9d8dd42d88f6fc986baf0d332579968ec0643f628f2
