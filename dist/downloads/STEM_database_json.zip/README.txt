STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 049458e13607e13ac4e00caa0843d615444db62f96a1b8dc9fc64d4450b38305
