STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 1a5b880a518b727c96fbb0d4beb0044817bd5ab8dfb0ddc25df29b187390c63d
