STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 6934b417b2e0fdfe4c9d07607b7686d4f0bad8f0222ddbc001f1de7cdf789f6c
