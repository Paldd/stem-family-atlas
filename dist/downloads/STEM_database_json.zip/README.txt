STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: a349e0321eca599aec941f560c4152578c65f0200f44b937109d39f61635ddf9
