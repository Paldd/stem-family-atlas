STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 5ae15b1573bf41291827a6aad347033dc24d5a12f42a25fd815908375183dc23
