STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 9221fe69dec507ceab0b6643f520294de53ce64cdbf9372e436481eb8e7cc7ec
