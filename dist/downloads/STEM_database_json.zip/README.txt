STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: acb540e878d165ff6c25472be0b22abd55e5d714ab2fbf4ac3cd2e7f7790119b
