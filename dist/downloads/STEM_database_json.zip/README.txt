STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: c25129d5801b96624670be377137062d780310c3a69d858bad094afdf86d7cb5
