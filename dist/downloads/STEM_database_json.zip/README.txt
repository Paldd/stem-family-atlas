STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 1dea4ff3dcac6d4b5cf1e03bd5f68ec33c952cd1ddff419796409ebd4eaa3c80
