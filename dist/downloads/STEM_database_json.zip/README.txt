STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 9998d912604fb8a3dc5dee077aa4a06cad54fab2891b9974382e7777edc7703b
