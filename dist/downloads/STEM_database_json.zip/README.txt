STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: c6fdec7987833e542e2366149469d7773df31a239580b22c67555df5ffd07a3b
