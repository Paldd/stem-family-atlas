STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: f5384dfd74d707b8ef431600913bcaa42d2a215be91d3f1bb724b311960e7449
