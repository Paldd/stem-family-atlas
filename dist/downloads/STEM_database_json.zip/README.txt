STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: b1faddd8d871fe28c0d94b47599b4a5a62b082cc63861acce648211d06a08f4d
