STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 0f3adabf48f942718a7badb602902235ca522ea328f62343f2c54465495734b2
