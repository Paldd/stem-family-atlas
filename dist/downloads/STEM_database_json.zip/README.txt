STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 4ee04943d6c83a9a4d2daa69fb75fe158d1a7598fe6269464f5fd705ba121814
