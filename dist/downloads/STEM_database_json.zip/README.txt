STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 100d40b862ec1e71249d10889b65dab5c3d2d61ecf83a2bb2037ada976ea7c9b
