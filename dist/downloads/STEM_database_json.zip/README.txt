STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: c3d8b1aa2297443626be5f7e6831e38300211c0f2ac04eb06ae6b3c27f6f70e1
