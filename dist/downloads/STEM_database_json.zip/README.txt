STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 93927468a089e79f42b241d8c8011d7653c403bf4cf49037f6d9ca7563f35faf
