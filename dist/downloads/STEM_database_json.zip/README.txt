STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: b40b775386e22306f8c8f9359d82d4cd8a89cb5f98b48c7fadd801ed0e6d4711
