STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 1fe84508177db1e3d86d75964954395a189351a8d336d1493f157e9bb764f8ab
