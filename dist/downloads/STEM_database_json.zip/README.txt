STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: dc8701048cb009edd4afa2fa0dc88b7e2068a31b3047804f589acb670c44a074
