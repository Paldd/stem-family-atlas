STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: c09b273dd6b070830510c28b8f6a99cf37af168c9ec8cf1a41bd410f1e9d842e
