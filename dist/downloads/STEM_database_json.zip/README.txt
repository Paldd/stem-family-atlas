STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 770af581b8fe5d84a6caec51030a0558d31c9bd7886e3871c29d6e95c8e4b411
