STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 9c4be2064a090718c1913a39f0ed8b405c0c2d8bc982f231d3ad5564d0fdcbf5
