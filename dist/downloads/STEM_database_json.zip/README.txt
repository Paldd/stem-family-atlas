STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: b8df531f16950309b8b5e7f6d40b4e0d281d1f30cc9ece5c325722fe578112d3
