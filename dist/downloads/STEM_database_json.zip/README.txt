STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 6136e23029f1db4a3b648815de9d90cd3bf3d326bda0585a6b579bab2625a9b1
