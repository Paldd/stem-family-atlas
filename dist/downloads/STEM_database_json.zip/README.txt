STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: c5ec6032e2d26146a82e53fa887e6ffb4dd9bfbf4ca8ea0192552e13afedff3a
