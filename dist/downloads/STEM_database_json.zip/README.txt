STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 18462a0ce822d940a86d6bdbef31eee4a4f0818c47eb759ff9eb7d552dd02537
