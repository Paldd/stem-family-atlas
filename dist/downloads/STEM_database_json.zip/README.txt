STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: b4dabb37a6f4b0fb789bf412ce0f7302f800e29d94644448b6efd1b6f5acbb98
