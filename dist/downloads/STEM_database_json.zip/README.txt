STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 182ebe5d4a9d2971edd56670175b88e1132a51c55a61656e78f98af3648e8dce
