STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 8e88b8840741c0f5ea46d579a4beaef51393055eb83b9d94d5ab79a837e71f2c
