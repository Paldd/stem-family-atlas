STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 4adf40024baf1a3e425995793bcc4bccb2312d3dd2b18055c49ba322463a1b68
