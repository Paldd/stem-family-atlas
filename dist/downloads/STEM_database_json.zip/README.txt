STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 73acbc0129b69377848da831daa35b9e6181f27e38133d55df50af01ce90b4ea
