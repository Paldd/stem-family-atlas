STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 1f77b00f15225020a75d0a4863af3e1e7cac90f1b4a16767743aee21439d9e7e
