STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 2d6cb6317bbf3d29e61febe451a2f7d62d420c9b83f5e0887db7652ded752446
