STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 92661426373201d2ac5ab34b9d1f324a46775213739cda3c9e5ba87027c91056
