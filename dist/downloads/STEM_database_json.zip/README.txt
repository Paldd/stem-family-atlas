STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: a8f121de88bfaadda405db9c88a85c1164c723dd2670e1558f3411b4d07a8b54
