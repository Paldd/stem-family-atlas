STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 490d2ac666b83b4f641282f6f2349a7225e3f0521877ceaf32b69bdaab288d89
