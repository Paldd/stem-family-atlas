STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 53072752e40923f258f6799c9d688beafe4f975888311bba846e1bc97eea9ed2
