STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 535a31de796a7156f06ca5aec851d84538d305b9be31bba2c138d1737e94d8d5
