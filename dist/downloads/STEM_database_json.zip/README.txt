STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: b1759f198ef0473d1d0159cc8ba29777e05c5062e72c5f6814778481fcb507cc
