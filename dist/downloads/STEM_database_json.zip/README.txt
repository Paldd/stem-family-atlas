STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: c9dd959c8b10eefd16e9403343914163d92a51f1c2ee8ccc27047dad58cf42ff
