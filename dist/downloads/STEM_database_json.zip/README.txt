STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 2cd58550e2a247ce91fa09bcd509b55d9b5ab5cfa61fc2c417324b787a688af9
