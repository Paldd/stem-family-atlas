STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: e10837ae13e42af4caacb66f9be5c17280775f00294d7d17129de4fc9ab2283c
