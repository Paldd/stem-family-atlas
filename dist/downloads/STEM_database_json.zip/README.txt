STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: f59c806fb2fe04108290d9339de54273d08582e8875ce183e89070e2c0cd2196
