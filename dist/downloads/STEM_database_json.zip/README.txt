STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 074ecbbfe4ae8da0f75b42011b4fb42f14e122fa382788fc1f695f46b3bdec93
