STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: a7cdd959225eaff2e68327f419b7174298c13e0bbac22700af0fc56f61fcd33c
