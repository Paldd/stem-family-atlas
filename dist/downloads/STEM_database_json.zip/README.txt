STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 8f74806c54829392a12dcb2f36088dbd475c92efed0ee40cf57bc32bd82e2744
