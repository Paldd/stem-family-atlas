STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 65d028d0c835e2d2437b120caa05920f3aa2c378e32cde3eb49f85f4cd878dca
