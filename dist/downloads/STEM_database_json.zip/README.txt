STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 26a3f864cf22eb1b1584ae5f4bd9d9b623d3d56bf44462d3bea8fe6f99697b0b
