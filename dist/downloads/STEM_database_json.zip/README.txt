STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 6442c100f28cbe1e6138cec84effb9dfad0a762c2dcf3f9217459be5e1cdea6f
