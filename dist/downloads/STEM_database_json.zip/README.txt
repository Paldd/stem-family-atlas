STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: b515be411280fd7ba295356bea6e3865e3262c3f7726ed990ed0f8bacbbe9a44
