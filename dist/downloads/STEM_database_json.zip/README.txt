STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 99c51987b3f370810748a52740f8d527cfd6bc84936569ac1b25f6f341e07424
