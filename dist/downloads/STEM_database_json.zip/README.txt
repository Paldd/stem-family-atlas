STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: f31f011ba59780e6721348e33b6798107ff4dcc18640067ae5ef22ee3bced11f
