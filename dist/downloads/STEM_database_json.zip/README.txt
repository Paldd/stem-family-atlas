STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 5d16731e9788e5324a63f9b130f75d4d6766e8f09ad48c2cacf2f0114d4907ce
