STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 755ca9b8119a623c85841bb30ae73f2e1cb07ea38c9e003079256d593270e340
