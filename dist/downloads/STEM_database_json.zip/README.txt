STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 97ff00b7d4611a9c0c42ba5678ac7c0cb8ce0a18f699a10073d721bff9784075
