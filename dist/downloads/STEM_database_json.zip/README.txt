STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: a8f2240c625aa1157a0f2383255cccf5cf952023398cceb37f8ffd234b7113e6
