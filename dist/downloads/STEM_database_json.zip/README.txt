STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: e7a590cf2b0c55e28ba744155aa6cf0580305df02db49e32e6c29dc779c501d5
