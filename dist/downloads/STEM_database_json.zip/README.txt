STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 3b4b00b719a150f3a2587a533a8c4f8648bb518e9841874b5e60bb200614e2b1
