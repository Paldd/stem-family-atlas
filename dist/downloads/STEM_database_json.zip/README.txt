STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: d4e263be4c9a7913d3b2c066ee746df3d4cb48d9aa1113c7e4de307b34cbfc53
