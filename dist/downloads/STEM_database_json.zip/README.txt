STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 0638c7a69cdf025c305da739ff2e7382fe36a19718e43cd0168dece09f56e484
