STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 3d2d0412e8fbece8e523fb676a02763f369ed4adae76457320ecff38d98fa3b6
