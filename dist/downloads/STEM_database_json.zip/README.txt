STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: a0944ce2ac9eb026121607bcca0966311397048d92184215519f4cf76df71b24
