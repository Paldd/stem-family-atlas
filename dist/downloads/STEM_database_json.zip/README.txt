STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 31e7ab5d0b5281210c9d20ae0d55d0d017228434cc2af7973c7d492eb62d6ffe
