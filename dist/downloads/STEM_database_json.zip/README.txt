STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 6a0a04a597277c06ec486a41c4b017d98489693292cec7532ae1c3c640972526
