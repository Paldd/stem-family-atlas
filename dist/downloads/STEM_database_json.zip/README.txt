STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 7b86872c562da908aaaf2a4bd7f5eeb2a860466173986e5b3793b1412867ad98
