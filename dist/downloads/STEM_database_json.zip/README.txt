STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 326cebdecd5da51796071b0cdfd62caf59c7f6c34cecfd0bd96ad68f84965948
