STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 17909828a0e3069a1c0e33a57b0dee24be12938d867a5ffc8c0acc5d275729ed
