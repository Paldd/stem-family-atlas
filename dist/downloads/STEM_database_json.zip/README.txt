STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 7e727d46ec14942601922156a04b931423d62ae238040ccc11c50d01910c2c2a
