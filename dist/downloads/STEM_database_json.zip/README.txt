STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 37be83baf70eb54b856a875c54d6c64a65c425a26aa741a6a318fea1fdd37ede
