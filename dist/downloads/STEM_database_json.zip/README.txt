STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 746e5debb9f7cae11f8c41363d1b131eaba93dc7b135e9bb4d2f2a221cc2e530
