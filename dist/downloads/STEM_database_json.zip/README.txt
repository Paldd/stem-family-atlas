STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 7e451e3b58d4be6c7cf71137bf3d65c949ff6e66a284992b91bfe1d6316c6834
