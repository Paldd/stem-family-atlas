STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 9f4896e55e3f6e15478570f4527828dccffc0b836d1df3f53f324db367d8b7f3
