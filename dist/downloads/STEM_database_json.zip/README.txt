STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 6694256e553aa60eb30c8ceb7cdd536c8482f49762e1af5aaf6d6738943f174a
