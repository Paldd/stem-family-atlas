STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: ba100a0ef50b49d7291ee8dcf55f14897544ccb97ee5a530283f9e67c9d3de98
