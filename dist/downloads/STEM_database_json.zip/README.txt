STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: e049240b9b1677e00b32a5058ed5b1de776ea5c5d993b55ad58bf373c8f52b60
