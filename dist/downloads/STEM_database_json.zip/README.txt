STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 719d29e24ccff0b7f966fa198dae9cab534860cb6fb265c4a22165ff0fbd3b17
