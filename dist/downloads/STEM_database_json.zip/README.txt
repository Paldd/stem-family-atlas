STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: e818a81b39d6584b4c3cc87835b0cea5aa76bb33e6449dd67aba737b62f91bd4
