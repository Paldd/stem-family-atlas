STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 60cd67f9c1362e85c08228f7584c0ef400ce8ab9a4da01fac951ec3d6a1b3c9b
