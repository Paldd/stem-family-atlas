STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 82424f33845a5fd74752cb782c04dc3df047c85a789656e99a644ff56800c9a2
