STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: d75ee37f67ceb2379f4ff5316bfe00ed1c726ef701102b8fc04e95167d79df70
