STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: aab66d1db7b438dae888e8503458d540514e52a980662f1034b734579ea633e5
