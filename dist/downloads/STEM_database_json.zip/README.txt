STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 670620586ed23a701d391ee74030b52aefa4e90130598986acc2acc79ae61caf
