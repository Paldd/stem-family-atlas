STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: bef997457e847d4fca4509a4f7c78bbc4ee6e2e4c92df11709e96f58d11c9054
