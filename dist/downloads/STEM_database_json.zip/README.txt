STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: b5fc87ecce0fa30828ab797681c493a78d6cfb45235f7837e0c0c95924b69e71
