STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 11cd6e944c46773fb539bacc7a3fca688992feb9e03df8e963aa3f2542dc27f5
