STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: a80850503c2bef9a794b344aaeb5e036e12413466e496a1ee5ccc968aec62365
