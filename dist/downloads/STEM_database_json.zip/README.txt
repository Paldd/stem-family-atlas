STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: a4f5c2d71ac111b09a80347eef9f1a7b74d92158b1afb53dabc942a8c1d719b9
