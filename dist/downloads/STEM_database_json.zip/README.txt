STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 4f0c776dc70d4d40a6612bea8fbe8439fcac8649784e76159777c2c40cd5afe6
