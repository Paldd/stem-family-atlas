STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 8b0d453b84cf94c22ee62df41ec34d12e211110ac4fc82fe6bd23bdb60ea572d
