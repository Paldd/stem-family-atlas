STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 8b7ff1c7d31dc980db2243dd43686cfad13dad1623730bba9962cd84e01a9a4b
