STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 83148d6762b3b4e09a68a9322e485c260ddf748c43cc79fbdab18e754dc4e4ad
