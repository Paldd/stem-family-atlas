STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 48e2913ae88ebcca43b349a68119283e0b05654adbd2fa07dc9c7586535485dd
