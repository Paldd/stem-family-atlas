STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: cf591c1a096b747d9944702f5954b15933d79118bca7bdb0e3166294a5357349
