STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 4e8d3fbff2dfc6efb458d6047ab311b3deb717d96c4cfc597e20903a88f65671
