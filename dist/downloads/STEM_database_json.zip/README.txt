STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 3ddb9733286b7f8d8d8c4425e8db17703d15c76924b9d496741d8ce1daf24b73
