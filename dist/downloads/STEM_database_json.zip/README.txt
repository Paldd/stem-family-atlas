STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 5b4728eb44e2394e19fdf4b483fbf77cf14574053e09af39188c15e940bb389e
