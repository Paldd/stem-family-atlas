STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: be607715bd593a79dec4baab4d0a784c26b5ef4cb15efbe6b796ac2b0dfa2072
