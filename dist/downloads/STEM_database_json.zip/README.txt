STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 5b11b38655e564b77d061b85f4fdcd8da525bcc6b1475fd8537c3f2b1692016d
