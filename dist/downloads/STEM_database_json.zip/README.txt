STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: a28b23dc1494a963c521e700819042012a03cdf9c8c4f8ae4528ddf1f7734e5b
