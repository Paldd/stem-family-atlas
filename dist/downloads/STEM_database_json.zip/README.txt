STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 06ee40da55a5bcc56945957f410fad801cf1272afc2538b2abda3cdf4cdaa7dd
