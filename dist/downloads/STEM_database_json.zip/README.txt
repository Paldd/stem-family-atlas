STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: ff28b69bc0af92f9f12c30158371fb83f1f77a8a586b556c81693b603f5cfa2e
