STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 79d67373b3f09e665cf3cc924b44079ce8a23c7fbcf0edf92bec70ea41c88c51
