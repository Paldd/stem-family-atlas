STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 2bb6abdc5894543c21a387021a5904b5d8588e45441a0864430da72f08a58d06
