STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 1278633a43e5ad82829ce9d494c4ea3bb96e335904c2863f47982d4dfda62467
