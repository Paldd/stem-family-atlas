STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 1885a44c24861afd824e715fc63d41155ed52263914ab1aab984942ed8d79715
