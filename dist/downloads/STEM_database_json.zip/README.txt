STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 55ac1b40fa533b0a2edd6c86fcc72706215e17c1d2f567de047f611a3cacce00
