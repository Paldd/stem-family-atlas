STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 4599e587658f9a720bd4716a034c980aa77f03dea1b55a431119ae534e568b90
