STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 0c076c09cda9fbef9b9f2355b59ab09eac1dfe02ba51fc4618e4eacf35ab0413
