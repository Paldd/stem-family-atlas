STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 185baac64ccf68a45e9af7d0c99be0e431c59edc33ab23fab909fbc561a39b2a
