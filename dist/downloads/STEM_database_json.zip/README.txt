STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 5ad29d21d6bd02929f033850775858e0e23c67212576e3b6a3a1ea2849118dd8
