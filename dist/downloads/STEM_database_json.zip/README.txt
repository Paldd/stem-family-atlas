STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: baf27833e6afc94bb86dc35936c9d6ef8b5edaa7ce95753cd7ac5ddc259d26ca
