STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 04a21e46488f6b3ff1d75b3fc4527be50bee4e1753c665744a54338b808cc926
