STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: fa16c9686f1b2c8b7474efef4be18617e9b7bd30268259ba734ea358c56a6198
