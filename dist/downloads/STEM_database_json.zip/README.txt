STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 499f4b04308a1729da7ef5bc2424daf300c844b938e11090567abeac71d0221d
