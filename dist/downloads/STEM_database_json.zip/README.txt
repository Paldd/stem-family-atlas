STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 758d934036d86b687a1219557f468afe1cad65bbbf6b4054ee7e6b4b105eae8e
