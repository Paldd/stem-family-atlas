STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: d050615284be5f9ad70251a4ffb11491c71eff046db3350cd555d5ea4365054e
