STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 76eb02410f1311a01b9d5ede71e682bc02d7084ca5194dbeb53ad84e7e01fec6
