STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: da41611769f7743c008495dc4f88cb9d5e50da3cc377ff949258e1903616e259
