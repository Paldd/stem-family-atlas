STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: e9ea80e25c1e89056341edf516388c84e894598cc6f31356b7ff0a2ab1a66f82
