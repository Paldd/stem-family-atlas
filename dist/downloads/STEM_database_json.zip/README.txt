STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: c2a9944e8bacb992a0f6c19e2c745d4324baa09743b59515326f80c7899eb637
