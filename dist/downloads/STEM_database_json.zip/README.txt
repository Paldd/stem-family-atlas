STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: cb5bed636ec6404b5f2b283da80ee01ed9addccb8bd09e739ab14c015e181621
