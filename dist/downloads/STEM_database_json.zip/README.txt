STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 9702077c3b075638d9a8456bc2bc70ac5d4391e8575d5dc3cbdf4c46b971d855
