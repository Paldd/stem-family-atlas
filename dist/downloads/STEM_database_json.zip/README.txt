STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 1aef2b1e09b4f406790de0851291add7c9d085cf53e2be4a0e40ad98c21b3f92
