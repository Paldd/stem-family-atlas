STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: b3b35ab51ff429c4ad3fb37ba15d1ff2b8b6af366c26c66ff77d3159f8b54ad8
