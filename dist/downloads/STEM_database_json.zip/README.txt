STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: e4706a0e0d094c67b172aaec06b67a50b28eb36e9dc933513b01b09b8d829ef9
