STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: f304b8c3e0f96ca188639eb6c9e89d5aff83bd656f2aad433ba39d7f2b581b5b
