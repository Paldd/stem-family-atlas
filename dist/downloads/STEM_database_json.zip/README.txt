STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: daec50c5282885dc291eee51e1ae37f965a9e975a2535eba30c685a17b97af1c
