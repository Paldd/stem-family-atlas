STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 1e87cccdfec7497c706d692aa39bab89b210babe754abb46ee9ab01bfb339985
