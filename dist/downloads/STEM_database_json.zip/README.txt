STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 53e0d0ccab6b5543d0249a61a22dbe8b75051d68070d6ae16d742039edf16d03
