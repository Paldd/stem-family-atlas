STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: e828f31a0474d06e1455dce3ef589a111873b79d2bcef95e05f3ce861fbd43aa
