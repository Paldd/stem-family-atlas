STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 22e0817d27608d6e1ad34841344f38526cbd2cbff76df7b1827080237b67ad7b
