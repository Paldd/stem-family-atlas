STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 67a3edadb4ac9d51db268a6167b06cf5fd0dbd71db14c5101bab996849507550
