STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 9481a81faf2298821f9cf23a087cb31a2a302b437f7f3bc001ad9cb7de40e81e
