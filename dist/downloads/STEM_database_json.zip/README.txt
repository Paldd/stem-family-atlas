STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 504636446ba771869e5ba119e036b75863b3e91333c1e241de06c8654ea6cf68
