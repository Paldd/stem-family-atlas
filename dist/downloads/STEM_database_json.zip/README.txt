STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 1be375b9b0d1c3ba03cb377346d3ebf50b604ceb0ddfd8f94bf536ef95480dab
