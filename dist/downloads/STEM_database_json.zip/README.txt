STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: c4d367f08b10f5062b191eb9216c2f4b810902d333e5c6bf5a0067c903109e45
