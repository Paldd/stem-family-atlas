STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 42c17f3e97cf4effc75ed9cb156e3c47e13f8682332fa5da4ebbdab5c1e3eca8
