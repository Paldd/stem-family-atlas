STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: ca548c1d9cae6bb9f20f9489591ad5bf7f04e3b3a57e197f6c019d36e47be270
