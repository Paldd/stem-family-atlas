STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 929b3d3c9d3faeda44daedfe0a989524203e0808a72e46c48035ba65acadb007
