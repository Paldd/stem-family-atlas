STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 2756a19bfe182b1978c433eafb9bfc65ec7c3711adc6685e06a7da8964fc99fe
