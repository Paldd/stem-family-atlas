STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: c202eeba5f6bf482bf32e9cc26c784da10ed70af3cedd18dee08b853e7b23b02
