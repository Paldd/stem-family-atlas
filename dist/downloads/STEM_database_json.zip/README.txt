STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 0f9ebb816038fee45ca01550d4a310943152b4696c30383eb41dc6cc0ee97627
