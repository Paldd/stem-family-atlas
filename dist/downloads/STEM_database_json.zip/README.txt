STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 047e121dfbe6d2492155da8994595029a8476c838750a97332024df986d8a153
