STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 0c4a04945405b6e5b462b26a64c6d7c1d1b5718211cbab208b3ec8afaebea46c
