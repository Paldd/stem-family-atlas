STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 9864c09d9043d701b43693ee5fd1a0802d8439a887cefa93a3fd525851aea49a
