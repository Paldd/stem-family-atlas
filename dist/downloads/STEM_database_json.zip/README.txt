STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 9f18070531a22a630d81a5c0ae9dbcf07373f0e61e41c34398581f5d76ff1f51
