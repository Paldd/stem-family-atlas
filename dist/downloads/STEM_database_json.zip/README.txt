STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 8c3f9a175d36e7faf92ef26b164026aade99a9b665597f3146e3230d987462b3
