STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: a7c44d50404e9e8f7726a90ab2b46b03d8cb98343d8d9902b424cd87b62f733b
