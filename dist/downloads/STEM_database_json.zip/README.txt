STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 39c19946775e8e850ee7fb5d2c50c688d02180f23a9a817cc2d212a6e5a07ea0
