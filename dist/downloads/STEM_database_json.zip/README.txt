STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 95c4fe131e2de160c79ea489b43fbd0edf7177cdef2da2e1a4d04961775d3306
