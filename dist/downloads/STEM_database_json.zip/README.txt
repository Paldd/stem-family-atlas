STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 10e315abe0b9c4e3c5bca50fa2f2cc35d0b1195c6c63d12abebaf39f5077689f
