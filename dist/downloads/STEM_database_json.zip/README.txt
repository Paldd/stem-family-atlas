STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 173a6a5c5805555d103436faa36786802a650af592f8727a3af239a73b3db642
