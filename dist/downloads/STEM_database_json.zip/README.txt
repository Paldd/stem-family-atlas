STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: e7b577d22539f7456cc4285dd2cbc8798b45161eba5020359560813631edbcd4
