STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 2757dc0aef91b5f36afd2460cd8cc92137611d8517f2384812b17c61672553bc
