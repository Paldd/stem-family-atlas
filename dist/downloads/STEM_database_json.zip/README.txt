STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 12bd45da2010cdcae15756eac370d7c3bf131e08d8b838ebe145a0ddfb79bcef
