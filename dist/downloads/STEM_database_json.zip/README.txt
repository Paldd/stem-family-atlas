STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 801761e02bb1584ce4218eeb0f9c4ed7c12f50a396586bbc1b5727983d1b90b9
