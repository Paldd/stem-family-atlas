STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 4c0951d8f99e2c3c3db9fddebaecfa696fcd136318571457f8af021d1a40cb83
