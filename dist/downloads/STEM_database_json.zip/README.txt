STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 5c49601de8944d447dd2a9a4f82fb7c70f6d4d2ba15b6436d51de410ace2bd4e
