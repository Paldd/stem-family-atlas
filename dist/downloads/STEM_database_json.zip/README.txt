STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 86d8084c60a295155ab9fa97a2ea265e8a8c7a3490927950e8f004e62e0ac7c5
