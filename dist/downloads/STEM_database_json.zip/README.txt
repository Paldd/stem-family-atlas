STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 1d78bcf9c94566a0a572d9ad937eb58bf30a513cfd05cd85e7c66518c554019e
