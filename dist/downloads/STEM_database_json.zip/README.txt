STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: b61d5eb77a24e8e9a585f71c09dc4f90473dbc9e2d203ab660ab61c4e1f375d1
