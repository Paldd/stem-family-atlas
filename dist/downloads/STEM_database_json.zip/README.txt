STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: fd498190337a8753afbcfa882ce1c386856ccbd6d941a652a84d88c74d0886c2
