STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 15be4a64d74251c9a409d624c5d9b143c8db4cd83b2411b53d4cd42be8681321
