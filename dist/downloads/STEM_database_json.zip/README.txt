STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 1c8db80f59627c3de2ebad13c19b4b2d94ba7a6777d0d01812c2f969ca8b0d7a
