STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: c1fb9d53562c625605b22138ae4483148c4283812c74c8027d73e9129d6b5626
