STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 2305a965f07240b148359ab8c2efac3d6236df6a2958e661bf027f0a70074358
