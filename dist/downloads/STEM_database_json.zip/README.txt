STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 290dd54a1c6f6c41be8b963a54cb3bc66fc18f297e560d9a57043aa3a1ca11a1
