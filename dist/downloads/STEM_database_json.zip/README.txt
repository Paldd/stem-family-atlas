STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: a3ff197fcfef634a5d2241848374860b08afe0695b9891f8435f26fdb7a48b21
