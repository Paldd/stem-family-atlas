STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: a128a26a39b9b3a634c98f734e8dc07772feeb66c07c4b2ba854253daf7ea57d
