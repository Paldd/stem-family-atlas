STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 952d9b4d737a35e06c32c3068dab4557aa36eaec9129295ead8fca16f0a6f976
