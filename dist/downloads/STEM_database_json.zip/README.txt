STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 6cf2803c873c14b79b4a64e273c8b6b42b3ccec0b0f95d1e0a534738ab50356c
