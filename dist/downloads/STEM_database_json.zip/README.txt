STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: a8495a2f6e3a4171bdd150a7b0e3fe162ac6f3cf0d9e0743aab6951147aeffd0
