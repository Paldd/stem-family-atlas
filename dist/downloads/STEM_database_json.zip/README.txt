STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 6c7791004e9b54c2a7c6f7de7030028d56a674f84c43d7e38c74541eb1374f58
