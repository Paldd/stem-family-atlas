STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 87e2d1919b4e56ca8bf3c8f0d75c32ab32faa724444f5b4973f92b236f1ac0c2
