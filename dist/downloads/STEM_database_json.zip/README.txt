STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: d5dc3743ab00faa3dc1d54f2b9d031e0060ed983599662c4d9fb2e3d40fcbfc5
