STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: d832fbd94267a8d03ef86e8a09796fa6aba9633d259eaee60c39f68c93185eb7
