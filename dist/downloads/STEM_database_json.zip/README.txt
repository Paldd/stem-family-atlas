STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 4c7b8469cdd7a8c59935c6347d4e345ec483b2b4383f154c9556450c1d564433
