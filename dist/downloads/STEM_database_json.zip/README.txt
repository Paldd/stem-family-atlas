STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 9aec395a6553b6f014d42e12fce66b96b777002eb02a3b4207bdb05212f106e2
