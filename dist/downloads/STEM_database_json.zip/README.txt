STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: b6b863e0e0c1ba2165f2c77aa993a6c3c5ee9bc8cae81e1536843a8185fec3fd
