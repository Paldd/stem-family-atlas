STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 0179dea6f6f602c81d5bd550cd7886719d036400330405a4ca0bd5869ec3171b
