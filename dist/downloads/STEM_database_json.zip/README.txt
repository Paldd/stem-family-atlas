STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: df940efca988e41b6408243d0626f04c0fc263f198c07b0129cd26924cb360dc
