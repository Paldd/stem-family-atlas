STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: e99b6586652e0e098ee7edf65157b71e0223191b75f3716f6fa6217e6898f41e
