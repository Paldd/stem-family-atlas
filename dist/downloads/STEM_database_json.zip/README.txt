STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: dd6490b64c4304879ef273d713713c021bac3eb6e76f3277f0acc416d8cf4cc0
