STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 74bda85cf9e9a0026c410a0f37f868a23272c9c5e067c08ac02ff1d0bafef979
