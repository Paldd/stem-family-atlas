STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: e10f069490aaef32697e62734aa29329276129168e105b45a71d4eed44cb24d6
