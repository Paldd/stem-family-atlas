STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 95bfa07459abd90f6e79e398a15953c95229a739c411da9da760b5f62324548a
