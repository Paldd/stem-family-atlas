STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 1162e1b702c0114382220ac2f0a87fe2209c4386bc5f6594caebf7306d8a2afe
