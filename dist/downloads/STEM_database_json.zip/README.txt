STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 68d662c0f167e1b9eaab80f869dcbb8de5ad3c45f37f21ed8fc881062074d4a7
