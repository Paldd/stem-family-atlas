STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 9828328c229d4127049b1665997ab47e2032775818f52088e53afad97470fb39
