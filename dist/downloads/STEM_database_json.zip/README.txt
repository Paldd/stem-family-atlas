STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 73ab2ee59741adcb762906e4517b5956e089de8129cbc9053293bd1377a54031
