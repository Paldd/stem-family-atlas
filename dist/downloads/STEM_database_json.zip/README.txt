STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 9f828fa9cac9ea2191e96463b853d45ee54b4b964b6ad6f8b56f5a93f40b7d4a
