STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: d12141320ea15593b19e8d01f82c7bacb77589c750a3e715ef744159040e2029
