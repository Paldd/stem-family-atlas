STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: ed13495c1645f32fd126911a86b0d7ac8b61151f79269f7312809d19e8f60bff
