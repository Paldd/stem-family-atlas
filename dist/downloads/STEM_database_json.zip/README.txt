STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 9a8708c0ed127faeab28fe436ca8d7c6985cde1172f12964f8d998f5c08d5c85
