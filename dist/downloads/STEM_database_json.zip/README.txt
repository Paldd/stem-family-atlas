STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 91a370ae3794fb9da59fa09299ca044fe2884d6a14c9d030eade3f7b8faf5c38
