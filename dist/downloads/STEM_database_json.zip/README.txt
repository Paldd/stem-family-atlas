STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: aee782f0d329d1c16c2818bac446c887937ff5f0ce31301ef8f32ae2172b2208
