STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 46d3691dc5c66204e0fd5df86ebe76e6ecf3fa179f338f833588835ef7b08377
