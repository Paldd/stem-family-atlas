STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 537dc560cf259cd626dbd7217d697aa07a4ea198310e6897ef989ee86310f5b8
