STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 86805aa83bb6091bf8705d7c29814944fddd5c18e4fd9a844ce1ffa79197672c
