STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: c5e499e155258dc5c0628bedf010747a35ebb8e82d9d2ebf5f5c8c0527ae2b1e
