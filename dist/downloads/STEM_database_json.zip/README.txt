STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 5d8dbf7f1e07da73ed37a3d96240c836dd1ddc2e7826eea8c24ef5c4b311a8f4
