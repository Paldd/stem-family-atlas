STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 0a80f75744f7a6fa30c197b01ddbc2506e1ad012793d0ee37103360b70a1bee7
