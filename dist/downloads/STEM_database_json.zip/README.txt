STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: df581954da3d192141714206553388aec2f99150aa41a4d2340c0068b7af35a3
