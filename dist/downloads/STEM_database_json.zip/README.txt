STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 4d1d7746285591d6c83140f176d77064c9909e77534634fb84643f20deb19824
