STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: bd6380eaa7baea072642b7b54aac28c857f3545ecdbf25edd47b1fb00198cf80
