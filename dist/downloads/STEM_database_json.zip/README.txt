STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 046a15e969c86fecf906c63b153bec3c70a8cc16abac1f87e9b79c3ee28b0dcf
