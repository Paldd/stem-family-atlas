STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 01bb13fcc65c6aa3eb2e3cd3f207a8bac650d5d038d61508670bba7db4276f8f
