STEM Family Atlas — полная база JSON
Распакуйте STEM_database.json: внутри все записи и источники.
Сжатие не удаляет данные. SHA-256 JSON: 74a192caaf3eedc060b5ae49fe72ebb6ea31a2f5ea531e8f815dae0c67a95038
