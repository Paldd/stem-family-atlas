STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: b4262f33bcd23637012e24ff266c561f038d60efb2c4fdb958c68c1e97a946f8
