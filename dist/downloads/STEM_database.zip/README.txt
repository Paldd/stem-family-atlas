STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: b4bae29233d6ca229d592b132f70dd71d4e81411e549d39bc54c6f49d45db462
