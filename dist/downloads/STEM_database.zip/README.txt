STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 18de3eb6cb9a86e60a67a41b14b8426499971e6dc13793f21a1aca1bdfd390bd
