STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 111b35b3e598f1552f8351a640d1669a2e691f1aa34e87ff127478165d7431f8
