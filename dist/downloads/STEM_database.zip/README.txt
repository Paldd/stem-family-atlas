STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: c554a1a8b39010abbe51067dfd2347590aac5cd4aee0eb881b85155a874be9a2
