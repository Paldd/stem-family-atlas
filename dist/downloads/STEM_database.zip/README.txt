STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: b8e2b6254b8a2cb5b3fc0aa39650b75fe1b57387d93b6d4901843236beb07751
