STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: ea98cebada420f1d29729e76343dda6c325f06c180f73b6bb6a17760c9e27c61
