STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 603d57f3dbead43892ad021c2e2878d4ee9d96d7026235947d7024f21ac6942f
