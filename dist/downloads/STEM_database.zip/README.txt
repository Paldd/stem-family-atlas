STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: e8aac976c376dc0cd4984cbde15cbc5416617cfb748b3252e5575111bb7ce93b
