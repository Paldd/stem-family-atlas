STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: cda873d5908e25a96742d1fb8a7500b06db8e25b1b6e19c375ea6a9b36fd1280
