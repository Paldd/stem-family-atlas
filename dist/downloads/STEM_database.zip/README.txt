STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: c8c9179d7b9c64221d9283047a1a093bde0a57b7e1f532c8e63f8917e44d931f
