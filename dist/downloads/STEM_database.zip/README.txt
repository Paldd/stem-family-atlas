STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 29d2344acdc59c3a75cf89a33073c41790bcf59104b6d2c5c1249567ef25db00
