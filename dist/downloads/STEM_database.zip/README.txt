STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 1762c7fdbe653739474617a65e82c612d12da634bfc6e6997f121485bd0df4fc
