STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 0bf1bd25401603253ddc7b0049cbf26f0504255c7feb7c66af0b86bd3fccc849
