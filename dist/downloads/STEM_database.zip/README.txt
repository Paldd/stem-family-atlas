STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 8a0c1ac22be1951216bf2ed99820c64784c3b3fd6dfb2df3b57a0fd8c7509ba0
