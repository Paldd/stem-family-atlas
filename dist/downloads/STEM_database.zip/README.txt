STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: b919cbdf844d809ae51be43c95bb35f60757e08662c9ed929ff6ba7d49d7908e
