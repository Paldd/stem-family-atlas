STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: ee1515e2d459d5cd07765fde8d0c1533b885e06f29b76a8334ad11579e67e9b4
