STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 5c1bf736e20f1d25100bfd5c6a1d80a294adbafd2416f7cc8e795f0a8249a3aa
