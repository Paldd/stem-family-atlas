STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: a047307673f7abf4600f2bf0ee6278b2c14dc8f861b7f21ac449a76babdc6dcb
