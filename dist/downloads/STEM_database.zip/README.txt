STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 9e6c0c5dca3d86f2fe10f41051df829e5bac9f11698cbebb4aaf02605b66d54b
