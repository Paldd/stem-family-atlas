STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 138c0f0ecc4b41b37c22a6bc1b715894998d54a843c5df17fadb69b0579686d3
