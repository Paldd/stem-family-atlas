STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 4353fbeecbaff607a36ceb9195e9e7ba8effb0c7bd94bc4b33fc5eb4ee908b2f
