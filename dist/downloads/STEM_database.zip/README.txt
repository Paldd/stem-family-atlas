STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: c8e2581be56cff3c8e2287af441f8beb29e9b9f621a52b5bf95110fbe48f34f8
