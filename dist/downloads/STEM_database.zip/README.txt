STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: a165f064e32b08dbf5c4d8c582805e70db670c0c68e8664b39a75ca1ecc625e5
