STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: cd62d076e96ebfdc511495c8b8b5b85fa562af6001bb012eaaa3d3f964c960d9
