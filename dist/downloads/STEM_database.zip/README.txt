STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 25100de56dd10d1823d69c6c4e50a6801ab1587a1bc8aa32e2ff66d05b109d60
