STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 393b640a4570277d907f6dd1fbdc96c161290ae3b8ce5ef23a96ab5205be3f18
