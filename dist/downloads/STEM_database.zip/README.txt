STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 78895eb2edda5f78bdd00dfb6192ef888efb00b8b69476c9947b4595646d927b
