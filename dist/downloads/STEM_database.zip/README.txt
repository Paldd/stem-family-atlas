STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 269f61450c4f1fa143c477be2cd6308983097e37dbcc4d05f2d15a11d663057c
