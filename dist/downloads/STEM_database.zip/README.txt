STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 94cf8e77a006377076ef5f156284bd7152175555d9a8e1d5baeeae4a68d27bc0
