STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: aae0161665a9e2f920e03fd4947a362420fafb3676422dcb7eaad0f7ad445031
