STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 86e0b6e2a80e3abf343b4a24570bdea59204bb98e8b370b3a270412e8f2da61e
