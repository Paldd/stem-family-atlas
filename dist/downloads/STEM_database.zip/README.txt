STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: fb15b273c367b150303b0816edfc1a88ffb7ad5cbc06b3319c2ba094b5e9cde1
