STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 86b471e1dd6c1fccb49951fa3dc07709177475c17a2bab624e06c3d614d0b138
