STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 2602ef24681276b3b32be6900b5ba0a676827a5182d49b7f6e76586c26277dfd
