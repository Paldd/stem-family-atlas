STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: a7a898b6abd2efcc294b03fbf73f6a70a73cc1deddcbebc8380ea6e19efc7f67
