STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: d47bfed77cb93f6d29ae1894a6a2f18cfa582193d30e17b9706ef0196ecf3281
