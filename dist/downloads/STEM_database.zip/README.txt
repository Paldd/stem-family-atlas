STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 3dae97ad466715129448e5f602043ea08fd36c0ef13b1b7dab19d01708926f79
