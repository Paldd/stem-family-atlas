STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: bac4a2f077a4827861c35aa23f6c6277cc514335ae4ca109ee25544caa04a212
