STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 2fef2b0740a2df714d6a04aec8de14c5bbffdcfc8d58ca5934c5944c2435321d
