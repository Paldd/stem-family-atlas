STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: fed1b972bcff46d01c6eb5ea35e4b0f6f1a8c2e6ef5e5ee3e14b9d531348cb74
