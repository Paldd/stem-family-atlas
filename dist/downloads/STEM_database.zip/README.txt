STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: e0f65a37fae85ed7c7305389eaf3e0cf168fb728cfe91dd7a7074f049b2e21a5
