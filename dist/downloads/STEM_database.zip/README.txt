STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 0afcf81e59904b30ac0cb9c564b9f39708598cfa61033796b87bd0cabfab9fb4
