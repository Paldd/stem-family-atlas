STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 4ee71aa73f0a10f839de9fc1d52385d03661598b49e7eb3bc4333c424856e67e
