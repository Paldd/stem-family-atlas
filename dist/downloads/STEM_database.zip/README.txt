STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: f3d368ec6d13f93d7751e0ddef199281356a8d52ab716641cba7f9073f6e09b7
