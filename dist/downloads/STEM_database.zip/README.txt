STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 95fd5fa37d00443c078985f65924f55f89c9d5ff4f7b4a2a9d6603be92ba848a
