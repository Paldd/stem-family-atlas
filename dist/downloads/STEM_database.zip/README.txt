STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 1c5bfa6d8f5ddb320f43bdbb06cfebfe277f5ed5a38d3b5183ec2f1ebd1e6206
