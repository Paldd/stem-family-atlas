STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: a95d2a8d8f9fecc0b383c2fd75daa3e5931e8a21ffb4596fd02e4c29b9cc0b84
