STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 05b948c01b29bb42484a4ec8d65f937a7db3852ab9fb6ddcc56366dcd726b6ac
