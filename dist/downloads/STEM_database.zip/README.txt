STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 8a17dd4114336399642f6966fdb862e61f0c3e8eb0b7a147464c91aea4f609cc
