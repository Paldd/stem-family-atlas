STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 74037c69da9c3fe72759e12e4b5d1076a9a225bf127fc8f2deee9c1aaa23a8fb
