STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 01d28cd547b3b290507c4b660baef7d761b7d0d7296918da4a2453500f5fb340
