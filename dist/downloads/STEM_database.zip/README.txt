STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 4b246a5127d32a1f09698e7fc77be4153f5ed8f5a8d85c80190adeee8139e6b5
