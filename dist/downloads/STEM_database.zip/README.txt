STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: f0898c20bc318299566be93bc1a4308336020d55e2fba3ba16cba53c6379800f
