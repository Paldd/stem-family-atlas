STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 349c1e7690bee9f23bda8525d910b7cf7605ce06aa4f13ebe666c1444406caeb
