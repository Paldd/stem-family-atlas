STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 993d45e3d514003aa5cd95c1c80f2b57f47a5875f8f908b39a5bf53a07bd71c4
