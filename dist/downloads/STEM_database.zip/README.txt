STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: e558f8c297edf7b776a81ba62d28f745f1d13d15de6ada0425a1adf4c0cd8d91
