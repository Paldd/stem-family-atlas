STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: cc1343404308632692ddfd0e3d9b923a285e96cfd156f2fb1b5aa7722d236f01
