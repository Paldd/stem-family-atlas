STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: cfba40e804b21fd03ddae11c1a0c72d6dbbc2e32e95351c11bf0760a025b9837
