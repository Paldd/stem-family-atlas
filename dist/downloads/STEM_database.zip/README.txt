STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: dc4f69af5e85c645954bd6f5a7918ae0685830641085a65d2f6f404e1888e44b
