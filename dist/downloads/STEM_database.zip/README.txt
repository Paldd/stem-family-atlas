STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 747c05884c8133b4eb8dc0588904941a861005f0a12e69629db9b45c73ec1ef8
