STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 2a91340f09e57bfead162079b5ee9289d19cf5fd8c65015f198673caf080c3fc
