STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 4add98d1c9860de701c35e1f66ec302c979c911531c1818ad09c0c1bfd7a9ecc
