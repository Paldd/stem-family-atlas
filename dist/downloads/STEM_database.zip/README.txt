STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: dd8795e9158f86a0464191d12332d3d4d1104df39ceb81a1ef4d21d4c1f6ef3d
