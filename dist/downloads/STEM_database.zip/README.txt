STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 927fccae5d5d0eade6bf07217ec54e06904edf1fd58826956bc2812561c845ea
