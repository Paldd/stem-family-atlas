STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 6b9d650733e305f179ff1cd3a7cb4b721fd64e84d2858bd26d7ee228f348b14a
