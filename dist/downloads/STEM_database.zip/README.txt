STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: d35246051f856c11dc29dfa289ca4d55b17328be8055b7d4ab90688140ad4e10
