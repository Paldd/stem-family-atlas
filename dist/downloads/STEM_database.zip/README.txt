STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 9a9ca18452ae0fea34b74bd909f86188ab45a2002d0d81bf1557021769cbdaf2
