STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: ee33be3ad499ef39356b5c85b0f9467fe08b23f3fe0e988d7ebcac1b8dee5a49
