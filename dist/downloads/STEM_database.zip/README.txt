STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 509ed41af77d1d8a06227a8e37533db40255c0d17d2f31f147517d35cb8004dc
