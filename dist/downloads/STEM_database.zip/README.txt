STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: a28b2af94fd4b81750f22627175ecfcb6a62d2f6dd15c7fa2f8569adf6fecef7
