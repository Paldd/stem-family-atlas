STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 16a7d7634ad847b66b2ed9f61e1dce2e1a1a33004135ac71fabb6195ab2a5909
