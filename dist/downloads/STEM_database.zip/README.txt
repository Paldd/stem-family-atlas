STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: a0083e42a8ac84d226a1c8ef3fe439169a733e919efb27b0fc15e5125fd98b6c
