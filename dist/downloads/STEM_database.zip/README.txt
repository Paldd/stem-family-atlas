STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: eb93b05036ebeab8dd77dd7b0cf5dc358a3944f64f5146f24d46ef08a304d510
