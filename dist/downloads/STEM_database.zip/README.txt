STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: de5f0248f93c00fd1576da465f5ce9cb337ef4ea9ee412ae1504b3eac8c920ee
