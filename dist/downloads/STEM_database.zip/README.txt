STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 130040f6f04e518d72917252c002c6f4d9276c8cccc3ad359f6dccaf798f9cf7
