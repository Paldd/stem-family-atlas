STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 7e7219ca6c99ff348477b0ebdce5a9a907465eeefadc8b7ce6ab83e865d30c05
