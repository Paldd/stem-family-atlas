STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 73d2b9d536c37c1e17cb7e19b779d833e31090a2e83055f806c21adb9b01e650
