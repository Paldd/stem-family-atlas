STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 34f992b5bf7bf82cc4e8bd2c8fbfaa20558293b31cc190953f50d52eb435ad77
