STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 3284713b62521ec1dc95a05f65e09a2f90edec8d610ec8cb718b1cc85694ebe6
