STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 1b552b986fb8a4dc461a9e3a751edd41d7e8449cab71ea711fab521831330c09
