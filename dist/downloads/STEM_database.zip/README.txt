STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 7ce470a3b23c9ba71d233cd260fec7673c5acba1927ccd953cae7af2980abe55
