STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 1bdfdd85d9d0186ee6198d5672a60026c5bd0ed557356ed3eb18bd3a095c8ccb
