STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 6f10c1a7e3eabd3a73782a0cb49509ca3ef37a740d87d26b9942015445ed9d98
