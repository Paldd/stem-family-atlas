STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 76b395a5f489e6ed2dfe7bee1bdf80a6593270ccf2684b381dd5103b481e1353
