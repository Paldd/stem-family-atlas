STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 6dd1ba7d5a5ac0dee80f72fe2102ba24b4b7ccea47e058205d01b8d8258bd5fd
