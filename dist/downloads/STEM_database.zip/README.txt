STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: efdecc32e2ec445c0ea4e54a7921b688258e138cc316188d6f9b9a03e926a7e0
