STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 00d9cdbf9abd1ce969888e09d898de9b68a00f96c0a14fe5cfd2f31f96916280
