STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 6ba9fc8864f016d5cc9f8ae3f40cb303642bc08a581f41ee9a3cef7db4c4f39a
