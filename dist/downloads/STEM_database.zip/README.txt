STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 80969a5a3bd80c81b7335b522e027ce92f525cebb3982f6224dc3a90108b81ef
