STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 722fb5e776fdea2dfa6baead27d78f8f21fdafe254cdb73b94fa34ee3337c62b
