STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 158e0c218872c8ac96b2b95a2b948342e127cf931e5c92e78ed9e67c213cd5d9
