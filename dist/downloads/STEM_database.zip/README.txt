STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 420efe4f97376a23f51c511f8e82148dc54409839ad1e27a39485d7c3caf8b05
