STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 9cb115e9b29671eba63523652ee290cebca2bf5536bd8e1608d9c8baa9b3e73f
