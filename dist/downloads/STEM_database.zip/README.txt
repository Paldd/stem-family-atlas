STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 4de15dc39832f78919d02c54b5f9dd18a50a3c700d1153248ec2d958e110e3ef
