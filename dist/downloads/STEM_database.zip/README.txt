STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 8b20da174b17f44df87560d624cfdbc08ed5381ff5fc324de0cac29a329c8c63
