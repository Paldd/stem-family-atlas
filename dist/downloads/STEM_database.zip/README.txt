STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 6a1c9d065e75790ac0fc28cff18e1c60c18bd1eb6682bb5eba43be7e2672e10a
