STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 19b6f85fa8250cea8e559163c2ea8829e7ea892d61c17180e98f1c49f365506a
