STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 37d1df94589e34bf2f7478377142b4b50f745e00d83fcd3bdf3e55c146a68d33
