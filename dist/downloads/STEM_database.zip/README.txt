STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: f5f8f8ba7092ab213bee11b6da6bd032503112d8208d2a4adb8614a358b4f8d1
