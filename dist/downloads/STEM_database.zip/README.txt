STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 42d2efdff47709b4270bdc8f0e2c51051ffa744c2de4ccae1652aa29691860fb
