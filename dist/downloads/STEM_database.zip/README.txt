STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 9d84ae35f6c9f1e7c749c40874109e346cb7898429a5697625e64968f6bea638
