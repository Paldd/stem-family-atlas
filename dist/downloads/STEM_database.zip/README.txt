STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 9a5efa1f415d084b9e1ff3fde4253de6c704173d012ddf3e789faa3498ed9c2c
