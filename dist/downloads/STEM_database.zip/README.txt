STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: b62975742d1e4d36e59234cd362ef45abb041a6dd586c116f0bc1df5615bfce0
