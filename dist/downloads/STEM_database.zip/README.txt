STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: bf3278048a7a879a45495e3b5adc3326f14e99999b2c17da62488366b35e3825
