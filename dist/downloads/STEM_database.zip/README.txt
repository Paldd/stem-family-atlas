STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 88cd0759a0de66eab7aef81ba360255de76e3e5619d1ac35c7ff8022165c318b
