STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 637cd9a421e4bc0f632c1fefcac7352d25c56246eba92d835e1182e4e708fd84
