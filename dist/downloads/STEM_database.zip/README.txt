STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 98d3b55565d0190c5c22c20d9d1ab1b22825b5342fcf71e9554287548028fb10
