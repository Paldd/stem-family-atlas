STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: eba9865be1f699fd8fe6ec4735e55114ba8743ec15ebd7b3a190d8dba894a34a
