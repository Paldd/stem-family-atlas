STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: e55b4d9e5c365141ea4f9be6b1f3cf4db76b1dc069bde06175931fd7b24e6d40
