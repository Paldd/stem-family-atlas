STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 433289c20b667e8b8e9d88b553f55c0c7fcd504b656c0fa1faa55b19f78f519a
