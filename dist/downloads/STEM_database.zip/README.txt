STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: dd57a76a6545bfff0b2f58c5ce57012489bf8ed73f5bd124b96387e8801294d5
