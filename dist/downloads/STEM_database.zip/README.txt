STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: a2ebd83fa5a114908359729da34e6a3d89ebdc9baac27ef41f0f2e21814f10fe
