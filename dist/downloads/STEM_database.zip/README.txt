STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: ffded4b78005a7b74d11b7f949b6db867c37b4daa6ca44f559884e4551a0d9f5
