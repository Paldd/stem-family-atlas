STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: e29d59983d6b16b658cda2b641ad8d3d49c124fa184ba4045b49b93b1601ff70
