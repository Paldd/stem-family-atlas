STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: ba2503f95b96cec372ed941d54de4769a89a98e3b8bb34bad1baaf2f154f6d4f
