STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 8f594e91a8e414632e2e5f59f5ff46b0f44c722a319b242c5ad225442323b2b5
