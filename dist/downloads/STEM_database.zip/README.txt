STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 0e43393a8868d0271695fe73b91c593bb4b1925980dde3a431c2d8c753d20b1a
