STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 8aa45fcff8f953f8f79bc0b5cc6209cace52779b7870da68d7fa44bb6aa845e2
