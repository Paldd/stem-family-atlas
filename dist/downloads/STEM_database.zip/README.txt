STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 5f85c97d2dc82ad07438e912c9acf28d6c36bac0fcd65eaf1553e804280ea2e2
