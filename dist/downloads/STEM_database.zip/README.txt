STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 50c4baeca2d7ae1bcf6aead67f24cebbbdf0327ba4e84c6fb8c760265fa58ebc
