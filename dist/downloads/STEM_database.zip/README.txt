STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: e227dcc0ec559512caae29013007119aeda27cf8a05cb35652d4abfd64f7af44
