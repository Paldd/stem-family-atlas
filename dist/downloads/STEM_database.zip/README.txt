STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 00a7672591ef7279dec8985ea82ddf403a31525564b47f37b67969ecc808c8ac
