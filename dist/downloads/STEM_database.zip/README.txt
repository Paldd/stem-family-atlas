STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 57c5c2e972b9e5e1f5290659e6416c7aafa216c9eaf6961a0e2e79ade0b121a8
