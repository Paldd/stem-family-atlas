STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: e14fbf3d0b142851bd508f763a554771a5f4fd3eaef172b3e909fb0a67343609
