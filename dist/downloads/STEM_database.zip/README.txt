STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 9d77fa00d2de8443a2128d5ae2d672aada90d2b390568982a4aeeba2ce2da1f6
