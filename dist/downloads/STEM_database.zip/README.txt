STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 47878f018d1f8bdb4cd05bee1cf17039fbb51c5d93854b019b646693010c22aa
