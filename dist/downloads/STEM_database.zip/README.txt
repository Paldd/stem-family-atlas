STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: f27b80a26f0976dfbaed0186281584fba21fdb73b7954f08cdd5d8701c7f51e1
