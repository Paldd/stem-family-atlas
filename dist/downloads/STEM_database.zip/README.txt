STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 9ff7bce87af020a33ebfcdcf5dbe74d2f41a0fc1983287701c41e7c6dba9be43
