STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 0f1e2690744128ab62d4969e9eb09c04aaa7af549acf5088d56e4333d16c0816
