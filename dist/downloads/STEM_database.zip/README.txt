STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 74b188116daf2e32cb1c2c5dbb4256b9bc79492d5dfc6f518614fcc5cc381a05
