STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: c9d6e993e94b17d37c28bb33938373d9af347ca11d169b169320f896ad26ba3f
