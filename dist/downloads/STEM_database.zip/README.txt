STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: e3abb0eea998fbc89f79fe6ea32d28ac0d407ac448a1809085428a51a2c57659
