STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 30d9b15537839b8ff7d1953a444dbece68063b771d42b109ecf9b5138d2940b6
