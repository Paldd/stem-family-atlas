STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 51e21a6a9246952a8c9d442b95d0b2601c8efaf282d707bd0707d9c9f0547ebe
