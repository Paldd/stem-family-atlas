STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 9fdb71b6ca584f8a6c0998dcf787711d5c0d465e3c8b6406913046d73339987e
