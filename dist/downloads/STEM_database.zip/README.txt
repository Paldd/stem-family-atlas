STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 77fb93cc9e917f5b33f50e671e0ab7f8e466d583aa52ab6f8c34ecaf37b16140
