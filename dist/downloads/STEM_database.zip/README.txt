STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 0ec49fa4274d7e832166a0b63b8a23466dd7a89ad65934f156ce9a2b8816e6b7
