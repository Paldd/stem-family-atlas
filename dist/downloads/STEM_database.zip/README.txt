STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 92600b8f462a748ad2945369fa7ae1b8afa9d36bae1ad58ee298b3d3691f2ab0
