STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 364e38b8f8dde0dbedea9811b4d89f5f695e3f1c8f4e050e754abe31c747d8ef
