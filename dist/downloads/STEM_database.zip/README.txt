STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: d22af781bc9a12e9549c42b54e27179cf03689f2f2faa20f6dc652dbeb3d1cd5
