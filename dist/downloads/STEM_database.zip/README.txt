STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 7320c4e598dc688812e55b1e9e0917af636c3307b54c5c61fe340f71cc4406f0
