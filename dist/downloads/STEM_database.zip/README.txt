STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: ac01cf96eb26596ef512aa08e11a6cacb1cddc41c34101bdec9d7500a1d1df7b
