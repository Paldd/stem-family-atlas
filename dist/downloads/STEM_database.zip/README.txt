STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 34f38fea2bd35c6fe04068cfdb3076bd380418751083cc18d0ec3085a8387c60
