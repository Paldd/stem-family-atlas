STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 891f4a1debcb36489db59c1179365ee87b4e04618efad4ca7541cd1583d1a3f0
