STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 5d0b1590f89b657a7ca85d843d8f996df047ad2b0181abb45f05bc3e1fa6a42d
