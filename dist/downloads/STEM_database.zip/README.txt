STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: d1f36ad2dbb7265a7c2455c20d3df028de380350db3c45fe08be26387baf2a34
