STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: bb318465d725608c795aa3fbada02e61c218a69dc8860b9fdb1f9b1654f69999
