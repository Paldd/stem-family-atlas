STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 9fb34692a2cd636a38a372c557f9124f423ed0215ad3a14cc82c4cd49ebdf124
