STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 0293758b15e1c9418d67b2680ef8720c903024ccc3eb8efaacd96ea0a4f9d695
