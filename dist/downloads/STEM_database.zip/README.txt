STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: ab152f24c5249639f59fe592829f7dfdc678143017abfd1a04fe63c54979e2c3
