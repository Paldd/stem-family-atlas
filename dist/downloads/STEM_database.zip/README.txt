STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: d7d4010606bc6c9f0ae84327076c236f208ee8a553b56a180792d1bb3478337d
