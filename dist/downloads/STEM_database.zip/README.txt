STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 5022625f8b23c77ba586bf4fec9be8e5d02c408d71420adfa6f86e820d8e3825
