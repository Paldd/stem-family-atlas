STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: ee4ab25f32827dfb8f125c4a1d5138adc7793b2adc5af825d5b74d54e7445e23
