STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 27a59aa3ca9ce4e949619593c9cdeb676b8caf66498e6892b893c5f01cf58ed0
