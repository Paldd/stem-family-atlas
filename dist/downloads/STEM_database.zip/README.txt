STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 10b8101a88cc8b13387d63285bc897a00aa26a26f496edd3d3e00644e936a0a9
