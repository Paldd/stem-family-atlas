STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 4319373aaa5a979b79a5550e7f29addf0f59d0bd96dd0e3d2189b4b2b811056a
