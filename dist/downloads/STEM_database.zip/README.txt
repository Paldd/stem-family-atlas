STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 47d72d29d43848fd209646cb8a9579881d71f2c2e22aed323f980c83d02d2baf
