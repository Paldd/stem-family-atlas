STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 941edfa63f309162ec2e5f2407b0e7f68086440f69aabcafa0750b7ef94d5970
