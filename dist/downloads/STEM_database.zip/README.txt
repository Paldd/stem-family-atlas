STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 9a46e11ecd4ee069591d85a4eb767a8d34c74018e0aacfb49632866f3377769a
