STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 803b8f0eec9d5826a1a5f788ba0730cebac108adc4d1c1ebaeb374f9faad192a
