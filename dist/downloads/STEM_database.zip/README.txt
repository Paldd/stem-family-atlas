STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 94236b4c1fd3cca1d9d1c22c7aed65727330c7ed608cefa7dc67c2bc9c60b905
