STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 3fe5c9809b3b962ee4775abad60fd1351a03ef0bfe0e979273e8a1d0aca51a7c
