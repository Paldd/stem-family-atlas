STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: c4c9b8f7e85deb6edc8eddaed1975b48a2975f8c8cece227dc237f6a63d3c956
