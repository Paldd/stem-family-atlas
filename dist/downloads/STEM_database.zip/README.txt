STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: d08f07f998dc63f14ab38a605a4b86f30e97e7c4215b5e07571e2d8115b38407
