STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 33a931f937ea1c2fcfb810c220149569dfedaac91544be7ccc6c3151cac4255e
