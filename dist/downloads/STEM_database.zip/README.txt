STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: a93e2335633d9c0f43095f254aa3a792c8de19c6cc63bdd7801477c429389967
