STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 44bc1143e0fff10fdbdb4b53dd89965ef4495c63e83c04afead7635183ed6a37
