STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 55f8963aeac19cefea6e3726d2dccb21c74fb994c6e2a0e15ab190c6f2e779ec
