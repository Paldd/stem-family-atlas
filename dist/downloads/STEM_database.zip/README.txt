STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: b2d274a81f1b1fe961e97a38368d95441c37c3aac811d3d186a06a8dc4c22927
