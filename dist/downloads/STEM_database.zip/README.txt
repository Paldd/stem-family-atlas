STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 148d758c311cd98380d94445a4dfc2bd8023f804e26a7d402f882a2ebb234595
