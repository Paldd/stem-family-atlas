STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 9d7e9aad0f5168c8e871365d907fb2a80dcaefe2441f15a18010215519cf56bb
