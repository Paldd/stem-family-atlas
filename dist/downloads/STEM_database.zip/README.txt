STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: a911aae06b2c15b58de9048c0a73be2b83ce39f6b872b2b293d169744810afdf
