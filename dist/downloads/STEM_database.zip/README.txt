STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: f554c30f5678d7710e828a6f1d963058eb1695c37979dcb6db24d14cf065d3a8
