STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 0f9e7fad33408c6cc0f92cd89f79f8c5aee12cb65806f9bd415d0ae6053a3915
