STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 59ed7d8dd3c0f7bfe952c4201006b77866570c014de9f9393f52a1d9942100ed
