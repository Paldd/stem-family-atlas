STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: aa00241f0dedd1d0365b889a89bc81a66e4463d9e905dea0bb3972edf0493b1a
