STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 77f4dd7a12b0e767a912b09317ccc4dc1b0f40ef6abbff3ef23b9c4396c0983c
