STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 5a22cd3649287bb005e17ad7fa06386b07d15b0471c3676767b07c8767ffd4e3
