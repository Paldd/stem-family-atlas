STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: a4798e765ac438bc7894b9cd082634bc87b1c35aa9a4ca53862d0027b8fd1b92
