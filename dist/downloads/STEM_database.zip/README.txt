STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 92692efa17c8eb9166db9607b443f87340e1ee65b80dcadd0d7f42ac86553d6e
