STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 8918a05264459cc2ac429cd22526043c21f20f5f4e89a27a4a11e11912a1a9ec
