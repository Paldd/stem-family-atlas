STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 6d8ee4821efdeea48151791b853772ffb977a4793dfc8110ba5c13fa163391c5
