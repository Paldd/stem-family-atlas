STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 6f13f1d3dde09ee2778631028b2d3fce6ad2e463f7145855fa58fe49f48e00bb
