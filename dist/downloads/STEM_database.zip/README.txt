STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 22636bf19a6d005e0991c8e64b53e754d6d878f7fbf19644e012287c68cd2706
