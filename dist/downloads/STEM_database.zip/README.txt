STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 14adafca37cabc650f000f18cb9cdf14860b8b46e3440ff517d4fc9899729106
