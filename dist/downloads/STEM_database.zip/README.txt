STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 346154345b0ec09a1357fdf7fe0777d45136fc1a64477706d91819e96dc7c78f
