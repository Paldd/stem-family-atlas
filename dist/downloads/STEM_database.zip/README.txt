STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 8701a73384e3c6ea699a039572528caa2c6544cc0044fecec4fdc9e2187a9b72
