STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 15f27edc4f4b2595053b7aea7e98d05fa1ad6c3d94253ef4f7d5700f2c63665a
