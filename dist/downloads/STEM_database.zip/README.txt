STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 801f790ae30b90769c65b6d6dda4b86a29f2630872f5a6ec8718012814100428
