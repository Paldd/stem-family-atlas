STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 4148cf8f4503b8fdce0907cfb7dd57ffe3097ad3e4fa153544d86834f846ada1
