STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 1dee45abb21a0902beed37299fe8b75a230b41f4cd3bd832aee3682799a52b3b
