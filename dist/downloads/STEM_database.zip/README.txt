STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 5ab3d5c0b4b38aac2e007ed48f8f0370f6c24ca6f760f2575340141543bac642
