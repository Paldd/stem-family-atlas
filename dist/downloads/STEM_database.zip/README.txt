STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 6dfd61c2e257ce54fcbb807d9f336f5a748f075764336ee211f396fc8eaa55b2
