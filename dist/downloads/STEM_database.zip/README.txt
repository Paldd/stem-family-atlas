STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: abf5986bfe656474653182007d6a9be5d9672723801c2663155b2c3288d3687d
