STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: e4dd795ac66fc177dd63c8b6e16aed441674f60d7bc79dcb2e584451457d4ac7
