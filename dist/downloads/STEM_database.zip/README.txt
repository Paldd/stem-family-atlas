STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 6d0ba622c3647370a785c1e39f8b824c97d01dc2b664c8325d9986dec1ecfbf2
