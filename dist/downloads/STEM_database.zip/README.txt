STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: e8dcbda1929e2c5e1ab8472dff9a68d54a8bd18db928fe3d3be85abbdfcb52a6
