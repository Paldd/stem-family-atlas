STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: b8ba8bb03c0ae8796e84926cac9f9fcefb673f7cc6c6154602310f8780549f3f
