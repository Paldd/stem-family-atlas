STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 009f2087c466da368adb61bd66d53a7bedbc236adcabc4aac877f5856fdf9d69
