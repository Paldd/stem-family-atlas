STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 592dbdeab3c0af67673eb81b97b4a0d63cff40cefd07ebcb1f90e4442e63d286
