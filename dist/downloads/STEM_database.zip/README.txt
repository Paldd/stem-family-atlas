STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: b1f914ef3503503ad78fa7edc4d6dc400c246863849f01c866d10b8ad19c61cf
