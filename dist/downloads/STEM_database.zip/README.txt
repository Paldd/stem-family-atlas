STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: eb09e4e6fefaf1395fde7163703ce769c96497513d0ab70aec34ef0cca9b494e
