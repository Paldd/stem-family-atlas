STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 7b014fe3245b0c8a0692e8f86d21f6cbb1aeccf091183b7c26c1371ae20bec26
