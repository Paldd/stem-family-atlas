STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 6f5db8ace3f994a2a1b2931545885854ae58498957c10befc4cb8e45299b9aa7
