STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: cf0c9bf0711ca040a2edfa4d1c4a9c082bc4909cb3c1fc4ac6ca1eb20106df3d
