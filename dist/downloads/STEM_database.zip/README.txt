STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: a6b2dbe728e44b1ef9e3b9f32c3a2857c320756fbf8479cb9a66cdb8115e852c
