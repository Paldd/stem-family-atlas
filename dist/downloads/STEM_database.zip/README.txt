STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: c54cfb6e8c29ea715c332be94ea96d2839493b3ca6568923a3de7da8c6a33fdc
