STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 7c37f10e7acc20ac1baa5a19021a1b33356bee430adde4f7fa6453a21cc97691
