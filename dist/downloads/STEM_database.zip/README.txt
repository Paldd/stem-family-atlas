STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 0da8fa3ab6e1020aaba5e5740538dbaad046116c594bb9ff5b6d8aecee345098
