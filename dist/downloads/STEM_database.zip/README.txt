STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 8e6fd186e7a6c2c217e84f4c1ebe39a0c4d94dd1e8d54e826ebe34440f99e63a
