STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: f3b8f31c165120b07b6016c7498b414b07daf6c161c2bce45260b5504d1c5302
