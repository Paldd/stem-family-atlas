STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 52e0836fa9b86079bab064a512e5b23fdc0f4cbdd279e186327a0cf5993fa386
