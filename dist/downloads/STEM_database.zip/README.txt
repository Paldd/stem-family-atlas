STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: bcd51338b33e80b27a1d2c3c93b0f94a2bc97f49118145ef34a97bca72023e7e
