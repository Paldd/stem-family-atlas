STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: db95f6d04a8b45918fa7b2f948d7b01b16d881a28fcf4c4b837e45a1a3f8ef77
