STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 7ac85500c266679154226e188d9c9b3ee9dd57718034437f4ecdc0169cc819b0
