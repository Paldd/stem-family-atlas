STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 7afa592d75319a363496ecb2ab863e69411203d162c39cfc827fcc2d55679c1c
