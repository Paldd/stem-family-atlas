STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: eb0a4f96c74343ddaf0d602f6385d9d953764086e66e9d9c5d5bb97cb893c47e
