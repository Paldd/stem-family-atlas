STEM Family Atlas — полная база SQLite
Распакуйте STEM_database.sqlite и откройте его в программе для SQLite.
Все таблицы, записи и источники сохранены; сжатие не удаляет данные.
SHA-256 SQLite: 5807c55eb4dbd99d90e3501a0452fb2a8f59da6046f4737a5e9237c7c5ce980e
