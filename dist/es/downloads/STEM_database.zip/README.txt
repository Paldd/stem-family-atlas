STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 3af11fac02dcc3d1090aa5e9472742d62244ecfc03b94ae2e95a70d006fd6909
