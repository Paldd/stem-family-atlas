STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: f4693608feb18baacc16f429e3ca09eac5d2fdbaa27bedeab6577083c4bce89b
