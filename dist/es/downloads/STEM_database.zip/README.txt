STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: b997db0f0d949d2f7d4e031655777e93d759224815aa507d21c43f161a8c9809
