STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 4f97e67a2ada0acadd00527bf0dff9a174c9667a11451b0c122a2475e202032c
