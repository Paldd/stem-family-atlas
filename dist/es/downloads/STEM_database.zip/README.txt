STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 3ef6b882ac0b2d227037331f0d2d8e505d58bcda876045d3c3fc4ca8085bbad6
