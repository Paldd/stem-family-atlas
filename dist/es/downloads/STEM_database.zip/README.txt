STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: a78ecb5979922997c7a21f5d765de52bfef171f0607d4740d1edc8eef66e0c1b
