STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 2ba243354495706e852b2d06defc64ab92432ac45c2186a5da389d1cf956c47d
