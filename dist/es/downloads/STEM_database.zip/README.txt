STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 7d07ee85c2c0f91dbea8a7c57b2980ab18d29148379a1685240bbf0be38eb85b
