STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: c47a1cd1e70f1aafc3316c53f8dd945156b83a37ada084ec20738366cfcafda9
