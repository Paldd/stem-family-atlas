STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 26441ea7912cde939f6dee6643de88af0f485588ce8c872e3d93c4218fa1256a
