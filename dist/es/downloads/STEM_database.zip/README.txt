STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: ca0e1f3c1e40005a5f8392cce381303944aedfea0bded6917e4c3614daf18ab7
