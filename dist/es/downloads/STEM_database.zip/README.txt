STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: de4e936f7006491760712108c67876a1007030770f491fde7d1e400f1deb1a38
