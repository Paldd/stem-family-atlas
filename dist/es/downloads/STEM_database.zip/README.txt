STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 0e9c81e285b2bd926264eeedc03bd454c8173df3e9bad1a305ce8060e8c58b25
