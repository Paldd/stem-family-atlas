STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 266eb681850b3f82da6629e7226dc98b8883f06ced89124bcb86b52893b2cde7
