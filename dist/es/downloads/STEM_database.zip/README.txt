STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 245d33ca13651e9b8144db7d0cb487965f70ec05f2b6cf2e5f3dafc8da2891c4
