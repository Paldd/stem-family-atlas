STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 0a024d506e3ec64ceedf21d912b6d0f9ca2a75b7af34df3915a477db38eadcd8
