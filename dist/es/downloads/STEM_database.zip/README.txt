STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 11bf4d6ee0db2b110d0f0a69969de712f3bf7a8a2f800bbc5a4c9909feaf6346
