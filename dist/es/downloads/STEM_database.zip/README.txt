STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 5635493cced088776aa230b93300bdfc141db4217c1e31b5c7c913e90a936f2e
