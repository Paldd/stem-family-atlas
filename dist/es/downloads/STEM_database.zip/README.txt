STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: dff87a0eefcff58b87bbb35e730af753a554895f35e316d989d701194dd10457
