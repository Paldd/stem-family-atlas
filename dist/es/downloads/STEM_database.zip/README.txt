STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 2d250291c47a4f0ceca64b274edce3b032b732f8f73aa30d0c1ab1deb8bc9632
