STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: fd3887877cd4c98aa481a6d64e53ada48e52f0e267820f1d08e91677df537e33
