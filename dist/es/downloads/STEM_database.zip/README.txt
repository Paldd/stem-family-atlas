STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: a92c650cdee93e6ca56a98a5c82ab58dc9fda92fe6c850896e478bfd7a51b920
