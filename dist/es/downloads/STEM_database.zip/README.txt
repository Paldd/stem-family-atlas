STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 9e1c40f19174d1344bb03e5c21750d3c7c7df13c4297b80597c8ca8c5f72ef07
