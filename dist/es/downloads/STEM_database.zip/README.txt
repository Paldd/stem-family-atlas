STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 80b595cb3e1c199d7aa69ea53a8773e8aea87d830422a37d9f8d5ac7b901617e
