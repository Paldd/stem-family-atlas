STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 3db08148159694fd80cb8534909525bbaea930fa72bca8c5e25e79aad294b112
