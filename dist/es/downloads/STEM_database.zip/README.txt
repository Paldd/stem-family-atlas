STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: d14da9aa574110f37ace1e98702d8a05aaedb4d8989ef0377ba9402ae851543a
