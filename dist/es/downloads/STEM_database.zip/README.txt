STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: e09649396441d5165579719da76ec820d6ee5d9285f2a24d8ad3260acaa87f8a
