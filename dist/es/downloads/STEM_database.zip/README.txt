STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: c3e494ec070d6b51a1aa23b361634ff0e98acbd894318713bf49334dea9b936b
