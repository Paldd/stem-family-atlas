STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 98334547241d8954ca9630837e5fc0b1681d29414363da49dc956f4335c26da2
