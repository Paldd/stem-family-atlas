STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 6b27834573ef1e9c89b1de870bacf956f3971b092af1c0182347d4fb24b5fbd3
