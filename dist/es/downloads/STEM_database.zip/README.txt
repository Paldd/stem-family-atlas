STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: cb29fa350bbe5f65b87c7dde7990835a919b83b04771ddc77af67061f5f9faa8
