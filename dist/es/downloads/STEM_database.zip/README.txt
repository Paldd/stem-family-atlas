STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 63454b1bb8d987f4e8091f2fdd93087d4491e38216f97c256c44511be64425b2
