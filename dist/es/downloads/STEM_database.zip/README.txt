STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: d115145fb7d78c2f42c961f9d83d1043d7802f57cec77e9b8e74d9220154ddb5
