STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: f9b0c570a763ce75c9537db0950cb310dc4a983587d328a64e6b906e16fb2481
