STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: ba48742f0961a1efc57ab0186fe401e9707f6274517bf2dca461fba3dcd90902
