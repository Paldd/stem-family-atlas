STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 6ad0b20f390e8dd5e40e02b46565b731798fdb075523f602d8f6bc987c706d5a
