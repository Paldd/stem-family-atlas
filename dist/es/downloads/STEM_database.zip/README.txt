STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: d506662ed892416a2a5a609e19eff976895fe36672ac54675fe796a9f35bb346
