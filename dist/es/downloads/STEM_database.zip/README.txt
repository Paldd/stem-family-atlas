STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 57333bd5362ffb6d8e302ef25b51a3fdbc3f17e954911bac648bf0dfbe27e0ce
