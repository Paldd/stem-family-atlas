STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 2c39c17717f1707c8e985ba3c2259c851a40a7b26490909c9126eccc755c85fc
