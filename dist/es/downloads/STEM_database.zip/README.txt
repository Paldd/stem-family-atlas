STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: caedbf538ea6f3ecdc3e6ca5136b740cf99753699367cb9d1b14593b54260782
