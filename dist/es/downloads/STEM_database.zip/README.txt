STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 94fb6cff76f482d5ef34f720dcec528199d867df7f18012259ef82ca6c2244a9
