STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 4d029fde8507931ee0d4e6c6957e004b0d1f349be79b79db8d6f3bd36be58d47
