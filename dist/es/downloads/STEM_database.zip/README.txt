STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 81469d5ce3a4ca2521b487a0dc2e6639da325fc325dc81f7b38af84dc21148fa
