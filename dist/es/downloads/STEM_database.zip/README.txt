STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: bb32a799e6ca80f194f636080bedf87266090f5f349cc8bc9d83d4bd98902581
