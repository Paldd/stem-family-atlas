STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: e96f30022295cf8d7c857386ee2828a8410f7458accfb36f384160800febedc2
