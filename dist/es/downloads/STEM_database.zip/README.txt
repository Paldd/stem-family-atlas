STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: d9f2a06ca65553c3c1ff569effdd289a32919869339a122ff24d3f77655c07f8
