STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 6e43e4c4ffb65ee36a1ea03845dc685bc6e4d7a19344c99d37818fa3081124a7
