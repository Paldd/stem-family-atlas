STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 0672b19f5f84858222904a0848cbfe2e3adef8a559473b7daccf96b6fc2f75cb
