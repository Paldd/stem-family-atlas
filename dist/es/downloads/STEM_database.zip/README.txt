STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 387fca822f60b8e826940f33b8bce55c486ff5044ae7739e2d665ff9c1a1d165
