STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: a70c45dac8872ab711e923cbe43bb0ea4715e6d1095debeeaa94b685f6bf0562
