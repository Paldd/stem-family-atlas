STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 9a6b96e52b7f828a1acba0461808fa18607a4202ccada2bdde3ae783217dc863
