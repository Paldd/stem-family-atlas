STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 96e9a94d2783bfc058db4d4d70950fedc868953a56bf389ba85b5383bd91946f
