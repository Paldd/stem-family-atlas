STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 1b556e104ec48f170b5809a901d4f9bbb5e695244b37fd2e7e2e4a03e4d74354
