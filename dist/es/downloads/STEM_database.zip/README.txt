STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: abd751df4853024c8f304e7865e31cf30d740c157a082af744fb175454e8cbcc
