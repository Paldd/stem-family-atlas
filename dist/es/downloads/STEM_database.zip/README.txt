STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 36aa1fc692405e79e30de78dc8d7e813945426161d33d956496c62f5855ec433
