STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 1aa7acb8db867e722ffd650c66cf3e46713a6ad0416d079df0a08b3868522b5f
