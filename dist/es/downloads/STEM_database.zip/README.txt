STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: d5dad796fe30c5cdae9c73fa0a687fc883ee024cbb5df403fa0987a2d1fa6dd6
