STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 7dc6e69c25942dca81f680d6b8255cde53d5853153d24f8e7e2fd8a9835252c4
