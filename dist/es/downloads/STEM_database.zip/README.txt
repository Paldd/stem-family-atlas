STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 62e26dc75c8937f6d44fe6db344c86fcc35800929214c295bd988dfa795229a9
