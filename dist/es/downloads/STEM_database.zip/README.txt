STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: a358599a55e10948882a960649a1867389eeeac8581e75ac3cc183a37e04e2b8
