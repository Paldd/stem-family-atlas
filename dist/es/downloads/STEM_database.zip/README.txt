STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 1aa31bacf4a7bf2828608f87e69f93d7bbb25422a68e91b34a84b15ea9577109
