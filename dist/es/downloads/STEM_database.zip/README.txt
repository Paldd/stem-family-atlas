STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 107df26e0c7dc1dbbb2d9d9b67718146565ffa7d56f4cef7ce4b0b4639143adf
