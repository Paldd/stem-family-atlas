STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 2f00c4aceb8041e15bd26eea3394cb6a51817139bab2e68717e448dd5879f28b
