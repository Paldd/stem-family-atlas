STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: f5fac1902cef8dfa22b788ed53b9650c0d3aca1c14522eb1a80b973a71d69045
