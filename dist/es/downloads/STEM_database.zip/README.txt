STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: c57828a0c826aafd1a637e26cad548cec26d9e594d9d25df85936f8d94b693ce
