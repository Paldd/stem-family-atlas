STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: c36e9d78a5f616ea2be6028a5f381197789ec47c9d4862d06bcfd5d26cf5bc0a
