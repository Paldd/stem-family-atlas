STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 961d62efea0b190f9716380f0eefd260928ba2da63eef78265d0215757ddc93d
