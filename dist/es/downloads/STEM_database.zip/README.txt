STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 3ecf2e9b694bf0c424fb3e3296ccf7bf1de8fe189e2ae220a4e5cdf4ee674e43
