STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: b6dd365664d0a96709bd74e3b286a859732c5417050290055457fa516c4bf015
