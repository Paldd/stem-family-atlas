STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: ff8c9a986e59220d686fbaf7b670c4d0a97da34df1a7b49aabf5a944080c35d2
