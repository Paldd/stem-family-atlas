STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 387fc8d62a4c629fbd4befa5283246340877bce54eb3f0d8c7c5ec050a989c3d
