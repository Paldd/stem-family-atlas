STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 89f62e2b5c238ea2491a03dccbefcae007cbbf3f5187962f08f27443c8a37a2b
