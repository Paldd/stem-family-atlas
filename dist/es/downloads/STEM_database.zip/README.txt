STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: e0825c3eb98b1ef951f392171b7054fbd9ea4e71a1b23f6a51b91afa34ca0358
