STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 524245d4e7b72c8ce9021e698356e8aa57c21aff8fcaf52434dfc5669655e0f6
