STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: a2feaaca0796667c5cc35095fc0a3b9c14d3fbb356d1657690144d380d5b6d70
