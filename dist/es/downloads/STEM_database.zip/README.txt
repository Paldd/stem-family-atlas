STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: b64b7145e9daa7996cd087f91bfa7311558df6f08779818dec9d233c8e8b5e80
