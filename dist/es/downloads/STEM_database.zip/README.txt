STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 6a91a50da02e628c5bf5d00fa59059ce871528b373ba6591cefff9399a7b7d5f
