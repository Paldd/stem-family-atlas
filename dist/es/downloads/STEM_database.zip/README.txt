STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: d37af228e9645fe90463f245d6eb3e2062648d6bac172c5cee7e89940412176f
