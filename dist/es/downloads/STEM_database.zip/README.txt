STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 58909ab511dd77a6f1e52b3bcce0500e9d6c238f3ade36436f35afbf75aa318a
