STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 20102de3914964dc7cd6cc2300ef60fd81b082f71042f721c5209e1471a88105
