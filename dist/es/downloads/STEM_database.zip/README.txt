STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 6e4a78770b6c8710c65ac0d55a79785ea04ed9e8d0a20e59140216c8a7093543
