STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: cbf63bb4acc31ac761e0745b4b252ab3202d6c2dfe64962d711f0211667f8383
