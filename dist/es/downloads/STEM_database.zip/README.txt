STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 9a83d31a25873b6f9ad36e0659b28eb785275bf884e9502b72e869f3a842bcbd
