STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: d7d78e7ad29586f280b65d606651b0353d9677430fab05555e06d637ad594c1a
