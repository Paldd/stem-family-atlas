STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 745f414c47811a78d78e718e9780ac5ae4f69274f0bb166aa853c9b2bdcbd079
