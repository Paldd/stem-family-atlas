STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 327aacf188a5d54f6dbb495ed3476b05768d26bb2ec8b9368db7b7270b69f3c1
