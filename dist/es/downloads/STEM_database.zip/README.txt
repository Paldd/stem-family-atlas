STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 4bb4169c6ace4a4c3739598e59da4c91df961910854f1f8903017dab0fe33cd7
