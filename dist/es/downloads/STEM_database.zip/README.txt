STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 8c0a153a8da74c084e3b723f1f116b7894295f54c2f291eec8241da1f71a8bd6
