STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 9d721015e22872aca8b26a9f5eea76a00e7e1977a981b122b1e70f1634262f63
