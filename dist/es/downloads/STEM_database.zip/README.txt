STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 1e2d85e1c85dc30c9b4e3759248d28be79a0835066f2f9f50969e750e301f30d
