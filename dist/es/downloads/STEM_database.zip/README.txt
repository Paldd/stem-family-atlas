STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 9e8dae5270c27ee9ba051ff2b4a6cef58722aade2beb542af811c1a42d685a20
