STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 93efd6bd9e351c0273c1bbac069a3fd27d008c5d0a18154be0fbbb4549943baa
