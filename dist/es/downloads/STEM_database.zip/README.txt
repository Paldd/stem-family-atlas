STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 796664a96df41a7b8f61746e21cbb17aec65896d68f6e4ec6fa31919ed25c51b
