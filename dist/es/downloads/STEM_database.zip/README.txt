STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: c3c48651483d2804ba62e74c02108be32ca05098ffd68f87e46cb37558d23b0e
