STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 280853af14ef4c0aa49f2ce8f92513ee0fafb0fbe7546f7fb2837173c63cd4a3
