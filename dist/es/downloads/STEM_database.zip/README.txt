STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 6b75578d24de83c77a3542f7f8eb93326083d63c1cd47aa801d8da4d92dc4e7a
