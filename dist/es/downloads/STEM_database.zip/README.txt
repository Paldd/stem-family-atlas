STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 9e4d2e65fb6868d5af7409e7dbef67fdfb0f4be252c9cb6bdaf3f04d1050e7fe
