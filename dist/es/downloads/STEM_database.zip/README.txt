STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 42ed5f53cc65e4a77c4b2f29e77b724c307216c1c9630702be5627fc0d1b23c4
