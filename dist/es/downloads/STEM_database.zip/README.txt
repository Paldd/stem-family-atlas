STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 4940129041ea43ee2374d3e542da4d5320a42c03b82a6a0b334bec5ec31e410c
