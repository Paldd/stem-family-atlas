STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 9d986e05009e1bb4122ce5b54e6407cdff763ac389a6f18e9d39174d7c01739d
