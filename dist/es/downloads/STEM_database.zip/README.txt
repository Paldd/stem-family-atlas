STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 941853b91901ae2b96b15aba0d0b7145d3ea8be78a8c44ad4d0f2470d8fd154a
