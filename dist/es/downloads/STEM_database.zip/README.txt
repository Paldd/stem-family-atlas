STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 2c6973a639243a0023e2db7019f12639746720f094b3feee16ec08bbb90adb90
