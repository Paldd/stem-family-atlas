STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 58118974f50b88ab7ef363d76de6ef44adde17c028cc889707f851ba24051c0f
