STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 1a3e694433b8d36fb3820b89933589d66c012089f49b7f79a9bd915ca55decb3
