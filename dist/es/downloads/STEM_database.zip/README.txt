STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 2fbe1e9dba9a502c7ddf4d6c3a1381ffb7d150e3466575e35b7250a57f3e5166
