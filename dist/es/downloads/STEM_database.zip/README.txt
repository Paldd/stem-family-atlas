STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 6b4e56ed1920078de3049c457e11097902aef67ef5f695fefcf17c10040e1adc
