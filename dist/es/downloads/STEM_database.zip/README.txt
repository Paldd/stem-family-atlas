STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 9fd7abc29e49399b31dd0008c5463058245cdbd63c91e9257c9f4d6575032bd3
