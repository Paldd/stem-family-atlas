STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 60a575bfcecdd62f4da860818a382c1dcd138d976519982170fab28df8c09faa
