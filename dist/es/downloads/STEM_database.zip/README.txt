STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 4b7d376b7954165365243d3e85c6473aba023664a572dc9f59b516f0e37d4da9
