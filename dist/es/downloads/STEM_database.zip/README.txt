STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 04c52533d80406ee7bb3638916651de908444049d6cee7ae7b9ebfe8e31fa1c2
