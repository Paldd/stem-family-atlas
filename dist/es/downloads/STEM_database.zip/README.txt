STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 55bc302965c62b78e48b515da456a1b5f41bc6738660f2657438340928d64f0c
