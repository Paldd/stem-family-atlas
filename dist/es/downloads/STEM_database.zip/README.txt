STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: ea789f8192476579bd1daddb6674b9521cb7137399d12a1555edfcffafcc88f2
