STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: a8d52978be0a6dfe51bf478b8685df195d6192bd428b0823a741f5c87abffa1a
