STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: ffe457b086d28d9f5d21b5c4f73ca1e9149b7bf87da9fecba0c7150d8e706212
