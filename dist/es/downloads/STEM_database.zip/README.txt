STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: f87dce46d7418bd7461e228c8933c564c822cc6acf91df4bc8ace67d16d2f06f
