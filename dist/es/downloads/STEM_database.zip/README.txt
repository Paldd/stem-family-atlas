STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 1c5ee421b25336c6b1077b41443c04d67231d9b6cb276715cfc57a831592d8cf
