STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: c9a6792f4dcfc366453f816b6e47d2087476b38138cc4f0dfc53b361042c8ec7
