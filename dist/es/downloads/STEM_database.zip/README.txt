STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 80e0a4be6226b090ac27e011b7b2da4691923deca4894aab412ce19b7d0cc762
