STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 8dcccda1b43893f688a1b37ed4e069920992303091fa5788f8f051f579874ce6
