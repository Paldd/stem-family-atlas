STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 89078925e90f5e570f4c0d38a67b04e6e23671981a60edb2b2d1b5690eb8e8e9
