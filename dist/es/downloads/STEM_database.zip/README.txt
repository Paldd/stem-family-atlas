STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: b85333ed32c24f8ac3f8cbc9f7ebe7f307c489d95e0604d2b92e539e7a2dcb33
