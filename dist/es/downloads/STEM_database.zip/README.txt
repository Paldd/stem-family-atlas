STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: c01aa4df983b23120c6d7fbe3442e5dade7a6256f60b9b1f5c680329ea85bf23
