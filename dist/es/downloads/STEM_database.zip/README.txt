STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 13297c9ab759d0f83e30a7a9e796778cfe1b713429c5bd7764324e210e74c687
