STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: d7797f9b79ee751d1c4fa897a8a9e2f58a11d8a0a82d2437e6ae287dd25a85d4
