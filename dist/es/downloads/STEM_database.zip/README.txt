STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 28a7b33e7ae767b7f55ce3aef6c9cb54ff6bb0490d9ebfb6aca948075788f708
