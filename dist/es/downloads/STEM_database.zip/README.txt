STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 7a49481fffe71a3ef49afd1ae1f0cc0c380586625b289dc6cc78c21beabc3d3c
