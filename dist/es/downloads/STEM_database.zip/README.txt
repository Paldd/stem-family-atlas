STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 6a7d52aa57b3f4f86e43a566b2f59412576de03931fe7f2a95850ebeec8f7c2e
