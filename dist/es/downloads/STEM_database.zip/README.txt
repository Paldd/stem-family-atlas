STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 39d4d7130e975fd81dbd401ffb62e5bbac25e2f5e777a9656ac17ab2e39b41fb
