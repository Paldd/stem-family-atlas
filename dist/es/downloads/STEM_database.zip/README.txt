STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 85f374ca85232f9f33009b6c2d0013b2694e5b778f8e0da6ccffb89ae5994f3f
