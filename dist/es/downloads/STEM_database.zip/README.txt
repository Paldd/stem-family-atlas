STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 518b11a4e2468bc54555aebb4c0ad726170349d78cc93b80ea7feeebc933bb41
