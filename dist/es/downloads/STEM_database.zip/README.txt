STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: dded93968d6512406603e09732bac49d5962cbb6bef71f6a8e8798000e5afcbb
