STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: aae9ca823b89df32897bad56dfc358009d6f1c0d1d4f8652b274e96d0042e56f
