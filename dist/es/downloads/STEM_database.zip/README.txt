STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 5f65f47758783bc2a7073a9e8bd29730c4892c1a454eee6c5ce6a6f4d38225e3
