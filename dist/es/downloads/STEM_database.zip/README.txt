STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 7a846830c2c035b6e886628ffbb6c6f950413a8e6cee398a73263354954e315e
