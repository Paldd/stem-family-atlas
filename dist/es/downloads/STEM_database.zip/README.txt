STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 252698f6c80865f1db5ca3e3fd2ba88800c7b9b09347a1e0e18d5a11bf71baf3
