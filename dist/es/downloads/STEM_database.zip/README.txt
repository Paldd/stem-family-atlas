STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 9e6a8513fb62f5e781ede3f28928477542632e8a272d769ad1751d4752812382
