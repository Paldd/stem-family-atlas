STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 98d6957c7c3b7eec63269231baa70bd606ca33ae1259c871df776d1babb571bc
