STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: f2580e05c927c3e919deae5cf81343b2a55bd977fb8d745f27ba2b942d01a01d
