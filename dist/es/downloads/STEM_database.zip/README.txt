STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 3f051222c9b018da43a65d3daded766d75acc4ed99eeaa92526c868053615d21
