STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: e17307a8e07cf1eac641111a60dbe8151dba2edb65fca4c3d3c83166e320c98a
