STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: ee12caa7cab2b208f6c7904cd87824ab2b782afd58ef556599004b87066381dc
