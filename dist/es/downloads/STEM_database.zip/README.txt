STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 15891819c19439527a0a4ecb22a59c24d3d02cf9fdfd777173893c824afd6b2b
