STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 59c6e7848812faeac649023cd82eeaeabc00f356cb8710ba6303c18032e14f80
