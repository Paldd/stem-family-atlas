STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 5efa5c28ea5863ecd75046da06b36e09da7eece63507a7d108c1f9c6cdee35da
