STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 388dc4da8bd06385956008e3ac0e5c0043e3463ddb14a46d618573d60f0e5a2e
