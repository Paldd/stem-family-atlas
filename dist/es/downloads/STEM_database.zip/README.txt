STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: d7b083b2425caca782d9617d51d5530dcabb82e6a9684934611fd9c412006ece
