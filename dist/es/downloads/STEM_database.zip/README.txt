STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: a0f288a85c8533352617d1e1e6360667716edaef785ac1402d701e5c60cb6508
