STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 1b066d8874e02fa3d390605dbc03978d6420be1f19915240c350c2caa2fba59e
