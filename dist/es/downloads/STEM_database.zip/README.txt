STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: f2e7706ede82797526631c7f6e8af6ec5f2c83f8da5b20d0a592cb71872d2ead
