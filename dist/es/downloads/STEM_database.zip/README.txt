STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 51b6c0d333957cf11eeba162449c59bb7a311083b20d2eede2f8736d083b9ce8
