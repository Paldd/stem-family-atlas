STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 7cd1e0153e4baadb10644bfb5d5ffeb9a8a1919dc207c0e0188b6f6ed72e850c
