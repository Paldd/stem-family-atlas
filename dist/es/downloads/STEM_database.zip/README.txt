STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 19cc6918481afeae5df35e162ffff07e449115ea55063996e62c4d83e269b1e5
