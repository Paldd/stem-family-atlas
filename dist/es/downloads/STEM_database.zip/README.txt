STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: bc4b40d66607b77e57e460204ff1f158bced5afbc55d451c23828ae3fff6b3dd
