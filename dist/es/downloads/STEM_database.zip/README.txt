STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 785438f3f861f8c2c4a3af813f38598dcd15d5ca984c73452880ad9135bb82dd
