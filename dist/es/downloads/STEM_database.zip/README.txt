STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 2c93d4f74c81161217359e71920a9e3f478a3a43d2f889f3d2e8407aa441126a
