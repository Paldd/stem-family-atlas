STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 8a78c4a402e20b366b67530d48c3bfaa6893e5e126dab5fc300f54725b3b2a91
