STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 54da2c131ddc5bcbe8dc8ff4bca09822e75c538c72833b1c01745f37cf258ad1
