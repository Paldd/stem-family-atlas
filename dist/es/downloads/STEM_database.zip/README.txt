STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 213c850183ef21cb339209241081542d9c7001a3b4dc30fa0f3db5f2eef0d4b3
