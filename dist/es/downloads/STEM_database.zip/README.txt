STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: b9115bf204c182d9a4e81845ddef477e7072604db95ff228a91f508478fcc065
