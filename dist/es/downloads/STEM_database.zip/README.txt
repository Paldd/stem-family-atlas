STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: cc0217f749089aff71b901a80aef84fa76314dacd2db072042023a0911c47d9b
