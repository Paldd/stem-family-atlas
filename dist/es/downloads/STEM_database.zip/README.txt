STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 41d73cbc7e1ae491c5b562beefd4e2253c5b4d585f6bd067a9a8546f6800be5e
