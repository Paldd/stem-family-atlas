STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: d651d0ae1cd71502c314c93f79f5c5ed0892e1395dbb34bdbdfa6fd5c6aae4bd
