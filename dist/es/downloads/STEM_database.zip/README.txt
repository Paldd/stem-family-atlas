STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 2f8327e5c427efcf7cc8fb814e4e26a7f9f50b88b6e70920a6797b0327109172
