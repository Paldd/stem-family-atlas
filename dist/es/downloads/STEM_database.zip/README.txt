STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 80cd5671c53f2f82f836c4b8278df54f2d06579c9403e0f6a46fb74821606735
