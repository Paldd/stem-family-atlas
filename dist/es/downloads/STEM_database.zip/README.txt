STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 81bb1430e9722e0fbf05590ca9ff63433f9c9e5d9160aa810cbb85dba33551d1
