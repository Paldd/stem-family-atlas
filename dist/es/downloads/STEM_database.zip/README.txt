STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 0c566595e284c7442913fdaa4dc1eb5d0c3259ab357c8d7054037d3c3965f898
