STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: bc42b317e0240162d8f449dbe1871967ba8238c6a85807a19c781eb2310eecb4
