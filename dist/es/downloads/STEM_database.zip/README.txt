STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 4cf3c8788c3a62c40ec61da2f835d62353972dd98fd8db2877f9b208a662a155
