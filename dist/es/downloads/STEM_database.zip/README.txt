STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 43faf8d7c435dee3730060418b0e52ffe9c02644756af5e6cc9e6e9cfe34c8bd
