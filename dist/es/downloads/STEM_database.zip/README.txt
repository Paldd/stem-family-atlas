STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 59b97585b8df0686d738d707277b3bac705c89ac8c5854e48fb28cd98dfa28e9
