STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 0adbc66f15c0abd3cff14bbc565dfb6c6e0f8f65cacd0fa54cc9ffa9b8e255c2
