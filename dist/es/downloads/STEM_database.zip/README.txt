STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 91f96b154df7beb78e29388404f98ed4771cd858591712d2c432b80865be09f9
