STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 5ec4f8f4c59c42792eeda74c2cc819d9b47b4103bd381b0d310f520d4509c17c
