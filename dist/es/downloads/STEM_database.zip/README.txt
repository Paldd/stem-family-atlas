STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 697da30e7d76861f4e7e17037be9f8902f8ca51a1bf2bb785c8147572cb41ac5
