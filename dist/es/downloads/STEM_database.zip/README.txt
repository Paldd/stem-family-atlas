STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 476582ec440b924e0e10ba2d5e0cddbbd0a59d4694dff514e87b32d3f97c2523
