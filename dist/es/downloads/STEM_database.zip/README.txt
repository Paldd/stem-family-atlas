STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: f42ed4f250f168ce2155fb8afd8d711fba8cb878dfe590eba0fcc3df2562b6c9
