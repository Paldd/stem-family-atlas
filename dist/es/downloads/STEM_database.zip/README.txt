STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 9fe53646ca4f78a148324bbf589b34d1fc9fa337e5280c5b3dddf3ef1ea33805
