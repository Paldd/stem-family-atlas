STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 24d1eab24f824499a6227a3e88c045c1acd00fe65c3c131af67bdf9621fcd940
