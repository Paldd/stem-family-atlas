STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 5ff68f222c32aa35d89a739d179059d8b5ee654bc24e609cfda8613d0e975af0
