STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: c860c50f8b9616a79eb0e0c3d6efaab58dfe36d20b816357811613f17b25c871
