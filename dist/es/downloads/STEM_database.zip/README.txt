STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 023e0bb06593afbb9d653cfab80fc807dd18b83c237515b9ad59f43276118de5
