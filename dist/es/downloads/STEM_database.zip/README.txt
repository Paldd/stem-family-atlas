STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: a60b8803344223905cdc9d1ba7af2c5db903c78d2661c9786f06e83a70918a24
