STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: ffba9b54498c9f8008b226f772a50e61c8e3ffdeb9d9fa6d5af3aaf724dfd107
