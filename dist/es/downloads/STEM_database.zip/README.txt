STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 82c16119128b4cd6e502298704599fb5cfab096d4ff0fb71afd1c370885f239f
