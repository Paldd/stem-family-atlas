STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 076036e8ab799faadd546f76d18fb5b00c72fd197404ff1ce774274e57383180
