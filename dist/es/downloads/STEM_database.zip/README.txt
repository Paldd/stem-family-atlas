STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: e9e3b6ab2c6429a216c4d43836a60b88d62d1b74ad7b832f340f1b25f7ef6242
