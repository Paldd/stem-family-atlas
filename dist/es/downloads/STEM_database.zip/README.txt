STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: b795aa5d070be0f84ec3db83715465f195ad955b77c1d99d7192ff8ad7cf78a3
