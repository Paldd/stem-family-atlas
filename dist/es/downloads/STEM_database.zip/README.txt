STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: d74813204ba46263cd9348ec61d171089bfb8bab4ab671b2ea8dc1b4563a492b
