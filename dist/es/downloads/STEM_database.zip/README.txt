STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 6b9c0f59d39e573f41931e14c28b24899283baf89dff064d331790a3cb0078d1
