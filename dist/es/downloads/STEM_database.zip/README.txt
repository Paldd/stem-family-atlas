STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 215ba7fb17850a45ce9aca7f2534f2b8b508a23145accdddf03a739cd3266fbc
