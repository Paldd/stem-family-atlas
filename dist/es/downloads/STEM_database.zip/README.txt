STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 6632f0968fe98918b4bb5f8978d8e4d44770426428629d6d2f8d60bec748a4cb
