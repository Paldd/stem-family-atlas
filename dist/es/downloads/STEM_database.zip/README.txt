STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 8f9b09d54906febcaa0ee54725bf07d08ba729174b71919ef72239b71bb0286e
