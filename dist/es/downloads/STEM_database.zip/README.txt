STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 87efe820c8fe8ff56020d575820b91a84200405b12791dba131cc70b06e119a3
