STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 4b2fa7ecfac18252f45e32bd8f363a4740c9c9ec041bd2c6e5f0acb6a52e4f7e
