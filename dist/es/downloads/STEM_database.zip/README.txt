STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 61abeb45afcf420d2746b8401351d13c7622f6d992aa41c646522e31ecf6575b
