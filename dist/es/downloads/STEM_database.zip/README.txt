STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 6095426c953a0268e2ea8891c339fd428ae3756a4a9f8d84a0e6b3f0ef1ffc98
