STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 6143cd9d85f855d45ed7033cc17df283664aad4727b4e73dffee7a060e783825
