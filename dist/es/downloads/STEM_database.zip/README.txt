STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 3b73e88addb3cd5f735eaf9085aa38b579d6aa2d19e0be003319311733817d54
