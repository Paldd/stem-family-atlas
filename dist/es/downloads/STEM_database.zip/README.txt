STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: d95404137742b9903f18178060b5cbb1ed24a1fc6d766c6f2ed4a83aed0349c9
