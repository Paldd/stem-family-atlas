STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: df67d36857c13e4b9d7b096fd9337e0752b5c900f698627fa5dbade8976ffb67
