STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 13dcc5891e713012f54f6e56a8ca2d957de30be72b414c435640e435bcbb4807
