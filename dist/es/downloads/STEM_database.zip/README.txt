STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 5ef7f0c5462eeae0ce87483a3fc943030045f34935af7c4d2345a2cc8443b345
