STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 58d416c7023d2db658ee1bfed076bae05da2be1fd0b6c13b78d61bbd9edf7008
