STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 3fd81f4c2c4896b7d9dd114bfe88624617da048cd7b8af3103b3d334740b3c5d
