STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: e855d44f4fe6e6546d41017738b8bf96b331d0bc6e6bbd6e62e8b0e125e813ba
