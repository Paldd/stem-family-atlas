STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: af00039c456b61b6b435a977f7713e0a2931f5c93e27eb2bd571f520d6221dee
