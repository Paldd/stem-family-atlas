STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: a58f3460000f315742a4881cb730f6bb26016cf58a6ec059f16acff913253c2a
