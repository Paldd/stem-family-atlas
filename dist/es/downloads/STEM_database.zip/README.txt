STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: ecb999c26cad31aaf1ca10b9ffba2426b5b503336f8df7d418233b8210155fc7
