STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: e6c60ad25dad685a054f0d42184e3068bea7328a868816928281ec0b7a51655d
