STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: e891fa9fa9d3628b845a669feb354175937d76c2b243db5ef96a72c917f4805e
