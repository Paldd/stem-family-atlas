STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 46f41bc0c736102e8744b98b533fb7104d29c4decbcaf36aaf8813a61e95b1c7
