STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: dc119296c561ab2ea6ed7667c28d4eb56ecc29c70d45785c4dcddc39440dc4d6
