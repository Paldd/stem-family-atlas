STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 560ce297c676f060ea23fa53c6cd379fa2f946ede2a25d94d9f78062c0cbdc6b
