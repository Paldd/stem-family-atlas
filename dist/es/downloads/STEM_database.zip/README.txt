STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 0b8deed2c9a8010f1586f942a4b13db8643668c6590aae9c619db0fcfc7061e7
