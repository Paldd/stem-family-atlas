STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: a8d2c2b74b3171f9f772918432347ce32f371e8768de734aa48975e4f4cb4dfb
