STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 22d0dc44afb5d81d5d87554f65cffc40723fb0746f5262adf628a3999eed082c
