STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 7bcb7ee38a70cf9d68efd4ff6ea0f6cce2c9f73b076d54fb6d28db337e9e202c
