STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: f657b7d98bd206b1c24e43c79c91303428bd01f35eeca4bfa2df909bb59f4cf6
