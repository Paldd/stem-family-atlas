STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 3a5431f71f3e888d45c1ce4991e3d81044452c4f394ee69c75e7073579118fff
