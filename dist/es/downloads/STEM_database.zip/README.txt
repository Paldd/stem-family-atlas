STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: d9de639ace8f3a2dba730034d4ac1fceb54aa1f31ee85c9172973a375bfd653c
