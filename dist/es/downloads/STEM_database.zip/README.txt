STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: f21bd7967dca6fcae5d1d04684d3fa81f6263f8ccaacf5ba282966b2240a143c
