STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 5e4e8ac4eedf06c6486ba5675edab4d24b83e960d236d908f6b63669da59c2ce
