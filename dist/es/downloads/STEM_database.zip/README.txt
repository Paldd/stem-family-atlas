STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 497b21a7b8aa9a0d6bb1c9f776f635fb340c96d4006d7bff3e8664bb946c7d4b
