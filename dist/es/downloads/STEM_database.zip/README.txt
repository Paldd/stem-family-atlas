STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: cf8af19f28252d3e272896ad1fa9c0d508391afae92d94fc15741bd6a8a00f3a
