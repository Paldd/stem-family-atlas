STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 93b715cb628169ecb430453b3483d26631d9a0f0b253d855380e596577c17127
