STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: a1cf54721767061c0d0aa43da00ac92d787dedbd3430511e95ec2756304280a7
