STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: d1ba782f920a2f86a92bf8966570f30d34584de9d50c72a7c87d35e106e6ff08
