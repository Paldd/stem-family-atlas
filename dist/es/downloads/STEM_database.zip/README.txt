STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: a39b903be56c3f8390b370812fcae27f544d3503282575392d0dffb2f451e8bb
