STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 0793ef6f575806ffde4d24b058631ff88a585144e2bf0f35afbb001ea3d046b6
