STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 29218793005d60e807580fe4ef21c1eafa10afa549cab311aef89ff1c4b99099
