STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 60ff747c99f6c10b4615b973965b68c537da2ee19392fef3fba7d903f7fb011c
