STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: dc68ea6a03e7756a2de4047c511255eb64d9c923ea39d9f0487241c0425b3e11
