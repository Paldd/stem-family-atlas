STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 01a63ec2edc3da779eaab355d1faae5af2dd1d1e771eaf638b340001d9453e48
