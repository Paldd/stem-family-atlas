STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 4aaffa02b7040b86beed5e64f195228152fbbec60c811add3e7be7478e5daaa4
