STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 4cbb2acb8838e8e3f7f3263ed134fb8a31fc9f43a2774c63cc9febb734c50867
