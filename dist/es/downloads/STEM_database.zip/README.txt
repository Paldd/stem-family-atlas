STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 289e4ac28756e69478ac5b1a59d050287b29373c016b4119e4a717b4216c2165
