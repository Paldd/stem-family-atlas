STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 5dda00773065e61b1dc5d745d0ef4a25e3b7a078373523a5ba193af998b546eb
