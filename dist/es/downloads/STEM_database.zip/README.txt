STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: ab1a451e988960f0a5411efd40fb1bb942e5e7c4576699c38c23127bcc059b07
