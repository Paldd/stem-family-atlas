STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 05637c2fbfc92bd45a3eddb067afd65e25aeb6d2ee849cf47b70b30d7c9e2bbd
