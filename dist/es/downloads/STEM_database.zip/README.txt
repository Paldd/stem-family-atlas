STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 83cfcd00a26a170c08de2886eb536e9b8ee60e5e110875fa0339bff7d58d7f69
