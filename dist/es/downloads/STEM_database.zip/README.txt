STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 9c7a08471e79c489038548e9237a162b99a2d8d5791f55171552c11a277684b3
