STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: e2898ab0ff7327a01a114e89cd0735ad21ee550d71cfd66552af1f8915701ced
