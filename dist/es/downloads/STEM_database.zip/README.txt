STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 0cd11b2206b205bf08d5d2f2d7ad1fa2805792c8fbf91af4ce62f688ca19c50c
