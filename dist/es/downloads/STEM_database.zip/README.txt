STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 8e1c8cc4709a5809080a6686b7fd4320124c984b35a484c8b6d5c019ff01063c
