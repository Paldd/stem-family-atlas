STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 1da71d6c4ddcc8d5645f7c69da684f9a1625e795725a84bcb812718745fd00fb
