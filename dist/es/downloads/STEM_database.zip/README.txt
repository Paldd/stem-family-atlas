STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 1b585e3504bee174e58dff890f9c78352e829e21afc096d368f8b5653adb47a3
