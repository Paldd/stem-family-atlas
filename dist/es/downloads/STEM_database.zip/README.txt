STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: 40ac7c257b5b8854c272dcefe9fdc017f5852e114fdc7ef9f43fa7582ffa6f36
