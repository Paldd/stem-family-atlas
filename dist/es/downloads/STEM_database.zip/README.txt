STEM Family Atlas — base SQLite completa en español
Extraiga STEM_database.sqlite y ábrala con un lector SQLite.
Se conservan todas las tablas, registros y fuentes.
SHA-256 SQLite: b078d5903db20315cd4dbd3dbcafbbfc55530e2d1152374c45fd8dd0acbc7478
