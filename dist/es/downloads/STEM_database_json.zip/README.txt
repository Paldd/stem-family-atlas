STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: f5b3129c1dbbce0e7a956416d4f326c9a418b4eed5a4b1fbd0b6c5aa01242f91
