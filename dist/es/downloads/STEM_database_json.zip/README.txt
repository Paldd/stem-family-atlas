STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: dd1a012bca3fb4d2782e55f4ac72c664d37284b897cbb11340356eaa28eccbde
