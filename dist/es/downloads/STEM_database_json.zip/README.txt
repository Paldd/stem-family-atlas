STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: b83a0a8dbf5f58322aa6dd73de7e2f1d862dc8bc3312ccce382926053b58d17e
