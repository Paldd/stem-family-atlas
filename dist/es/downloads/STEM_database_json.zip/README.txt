STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 16358a5358ea481a3de25708453345be2701bd297171417674381b4d3aa7971d
