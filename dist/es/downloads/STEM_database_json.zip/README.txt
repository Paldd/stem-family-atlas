STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 166a4af802b487652175b7afa16e2aef276012679e344d97b8ec1107bb82d3c2
