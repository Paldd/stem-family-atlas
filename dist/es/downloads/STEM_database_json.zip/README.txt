STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 51de70751621816146e7545a4c6fcb54e1a8c87d77550db6c4d213898d0a06d7
