STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 1f19b0004b206acae9cfcddfc80b503d76293cb210b7c7e83a2f41dba2088bf3
