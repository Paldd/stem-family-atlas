STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: d982f0c167baf75337857f39ed533bdd00ec1dd92aa8d3dcd00990a29cbfa5c8
