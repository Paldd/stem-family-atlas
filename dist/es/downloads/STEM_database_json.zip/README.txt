STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 84d214e9298298c215b4b01fae63ea7fad120a217eb3a0f5a86b78ab68429c14
