STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: d44bd8b32ea95346e2a12ff2d810296d75c6eaef0abf10e8cf8b0c5483e1a844
