STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 8ceb2446bfd392180e4b1d1e6fe506c1ff9cf65b10fdd1c9c4d13144139483ce
