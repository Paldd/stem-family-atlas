STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 9d6ee80f2c3fbfbd6835290aba123fff20775eadd468233a0618e1f7f8c82ffe
