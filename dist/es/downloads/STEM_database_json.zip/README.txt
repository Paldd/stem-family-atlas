STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: d4b21ec4ddd209df28b25ead24d901fd66a8ab1260373bed311132ae59ed1aed
