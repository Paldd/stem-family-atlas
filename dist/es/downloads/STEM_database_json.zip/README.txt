STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 6c1ce9fa3ab6c12de7601fc37573d9335fdc96bdd7e8167fe31dae75062f3fdf
