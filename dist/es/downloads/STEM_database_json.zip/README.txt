STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: e5294605f3fd84b31317816658f835fcc1296d4461a7fff9b172770782e8784b
