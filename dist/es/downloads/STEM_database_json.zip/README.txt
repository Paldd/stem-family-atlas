STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 1bfb8f70144c0b467df6756e1535aa90671e553b7a08f487f77e6b10bfbf0f4c
