STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 68af5fa0b3c1c272628a94d9f4ebb25e764dddf02d84b2f5a6aa4e5a06e52f62
