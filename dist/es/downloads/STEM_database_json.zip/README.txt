STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: b458046f3f9b92908427fbc87022111d7c36daaf0255922253587cd1b47f6fa7
