STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: d0da85c8cb0f2187f57dba3f0f6f81c185bc7de2c4ef728c23a8e5918747cd91
