STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: afdf6566594963298dbf7f8be7ffb3fcfa4011e86bdf23dc7c6bbd083d37d3d1
