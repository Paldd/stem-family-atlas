STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 2ce7e036b7f9a8af2d0c67c9c5a96306640c17d642f88a3ee3b606391996a2b8
