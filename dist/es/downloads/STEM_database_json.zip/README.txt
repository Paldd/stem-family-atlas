STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: f5bd2e5b8c9419fea82faf1fd1949b022d2b333ef9eda9cc51f0b7c5648321d7
