STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 01c7b7548020922f06e42e30b4dc1ff2acec07e3f820b275204b0372a1879ca3
