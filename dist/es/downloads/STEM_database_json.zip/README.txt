STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: f5527d82753492a78cb1dbb293365b9bef74f464182568da046d8d6b991e4481
