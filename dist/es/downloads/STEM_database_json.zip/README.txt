STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: cce1c42a71db411efd7e1013e9aaa09cf7a85ed02a9e8ff5737cb3f104ff9e49
