STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: d50168823b0bde85570a8804b34176b00fd52920a019f9c6c25530d87aecd0b2
