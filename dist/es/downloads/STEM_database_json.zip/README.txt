STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 9548932a328a6776dae26fd2c8692b0f3c15a48f92ceb631e224340838115c81
