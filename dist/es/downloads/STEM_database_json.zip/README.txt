STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: db08646d69db155a71456033935c6de556b8e1783d0fb47ff76af2564a079f54
