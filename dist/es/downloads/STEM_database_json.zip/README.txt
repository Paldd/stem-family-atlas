STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 0c845bfd5da2388ef2fc4f420893a0a56815452af9ebe3b3fe6132f4ef417692
