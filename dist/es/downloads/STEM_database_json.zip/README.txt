STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: a5e5a0132ee9df6ed140f53ad5ef8c03ac5a49a587ed4c8b38cd3302abff7a70
