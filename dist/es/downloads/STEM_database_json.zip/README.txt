STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 222eb7e1aa06e391fe6bffbd001a16aa58763393a11adde956dd760828389bf3
