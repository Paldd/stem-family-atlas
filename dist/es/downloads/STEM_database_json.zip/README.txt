STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: e4fdceb7cb73cc5a5736aad7e49ca1c6743626835ca2fae55a91e127b04d6891
