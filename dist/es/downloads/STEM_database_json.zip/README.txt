STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: c470dd1b934c5e31aa5fadf85634dc4a5c73bbf9c911fe8159702d447282b943
