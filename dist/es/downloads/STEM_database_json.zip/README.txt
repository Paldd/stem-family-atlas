STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: a838bc76b42a693482f85d2f99e527113401cb5ab394d24aedf247bd14992b66
