STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 7869d5c40d191b8f7ca2b726bb54208546a4ac83857679ee6223ebdd9aa15df5
