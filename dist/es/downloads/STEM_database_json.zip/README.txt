STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 6724bfec458309611f533bf803d08dd87f56e4412863b9b9451804b27410053b
