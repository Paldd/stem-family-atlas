STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 69d5b3c863555d255ec10500dc6f236f270f6869858bcce5237ab2a587d13c16
