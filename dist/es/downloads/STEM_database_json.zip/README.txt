STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 7194159dd954338acc343a5836e314986e1eb1da3ac7210cdb0beb5cd3973ab5
