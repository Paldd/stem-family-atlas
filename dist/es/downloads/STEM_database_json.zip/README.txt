STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: d10a6543eb77c7228587b5cdc12a3907604c8db14c039da138c5d2d1ccf21b67
