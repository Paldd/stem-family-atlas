STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: ae7c4b0c01d34f9b11b3d2996ce70e2fe82a75f4b5282410dc59b6c3f8db04d3
