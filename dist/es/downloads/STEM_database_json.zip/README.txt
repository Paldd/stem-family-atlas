STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 99c46313b5a2c8ff49639fc8470c16f5310141baaf5ee660149d90e8d70b23f8
