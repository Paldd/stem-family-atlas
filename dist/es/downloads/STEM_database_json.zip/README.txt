STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 6bc69b5326aed55a061dac4b52e26b167c450543d6e8deeab95a40930c106be8
