STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 59fc930f1f7f5fd91d116a9e74a5e95698e6afb4fb27d3c43230a2196ba06373
