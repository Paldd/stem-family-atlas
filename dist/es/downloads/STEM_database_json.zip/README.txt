STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 04ec575a32f506a07c22a9bf862eb8f34c9ce4d01954c12559e91c755690aa1c
