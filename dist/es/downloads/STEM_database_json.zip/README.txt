STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: e800146069eef4210ceef851e6270ee0195007a0dfa2cce5cc902c9c7dd25946
