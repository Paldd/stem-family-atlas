STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 50de12a23a00a6891c0ccd964e84d1e3f28ad5316ec40d8ed120731ed53e13fb
