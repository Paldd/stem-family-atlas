STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 76e44a0d51768905e1a845e214a6f4a28dd2e3b366415491c755878058e8b8f9
