STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: d5ddc7be351226cd4bff2f753a9ff7d2e62ce8fc8597b0001481e8d01a2efbd2
