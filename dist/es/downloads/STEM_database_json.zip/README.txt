STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 2bca5efcd2f32380e66b26e296afe9ac3244723865fb3feb7a3bf2d413ba98d1
