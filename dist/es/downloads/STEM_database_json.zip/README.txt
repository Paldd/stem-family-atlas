STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: eba475b2a201e22a5f8a6bff62b2885b931aa8aae5484e4160ee1ee43d4d7538
