STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 267fa4b8f165ebbffe5c3c17947daef07b54db09c46a6257d825542ece0664fe
