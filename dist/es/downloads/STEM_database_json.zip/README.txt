STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 056f3b1a94cad672f2e7ac4b475eaeaf5bc59e47c8fe7d53adb59d78c7469f9d
