STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 1ae4a14e4d031b8d3970942d225329ef426cf45edcb03169b244e1da8d20bd46
