STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: ec30538fd8e27aadd4b890311c9fe089c3bf0a325d725d975ab7c3167241c86a
