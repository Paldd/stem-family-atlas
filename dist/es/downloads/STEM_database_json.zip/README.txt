STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 8aecad6fef19b154adacd738c50c8cd28d88c4a949a6a83d22f5c590c3531abe
