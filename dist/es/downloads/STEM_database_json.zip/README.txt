STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 934b25ef64d3b4b7408522ecbee2ac4b45dcd406da5a650c5d1ac9e0a3e060e4
