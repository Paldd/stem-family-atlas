STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 5289bcb122c0903ab89c2eda463601337865c1a534fac593477e6b2d715f9e4f
