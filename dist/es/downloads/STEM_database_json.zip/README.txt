STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 124c932efad0cb3b64aa8db07cd337571b52abe9fdaa32f5ca75667bbc443c2c
