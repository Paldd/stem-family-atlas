STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: c5da2043f34b29e40b57abf176f5004dc3ac54c0e13677fb3e8d670664fcd07f
