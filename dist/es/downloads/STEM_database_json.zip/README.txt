STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 95f16bbebed49a2e073d871bfbf67e3fe5d056055afcb0e6176e9b6efd9ecf47
