STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: baedf1937d74365b90449d6f29a0a4e8e674d1a511e3fb79a2b1063c034f64f3
