STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 43fed987e5a7f93bafa8b5aa8bde6c98e08bd29ba595035a74766a1c05deddfb
