STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 010a0d141a677428705f346448f607278693e88da2e566424816c4edd2c1c5ac
