STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 7dd45ce83724ab738828161aa12637c1f83f4c6e5c8a33f424c819e7f291d648
