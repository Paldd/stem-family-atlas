STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 0658dd86b41d5de425f85f6263c8e8db5027ca7b1433318cb365fd6f3233baf1
