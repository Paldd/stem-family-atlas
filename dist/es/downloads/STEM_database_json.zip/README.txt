STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 5ab6ed33133f776af0cd4bbe05d3be92733448239ae7ee4967645a3a8912561c
