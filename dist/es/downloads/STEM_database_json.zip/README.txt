STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: d63fc59e764f9e5c8ee80259dba6e54141dd6e6f083fbadc82d1728de7de3165
