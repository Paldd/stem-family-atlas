STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: c86175b79ca51fb624a33fbbf84badb92d03697ccdc315b2140ac33d1ad958aa
