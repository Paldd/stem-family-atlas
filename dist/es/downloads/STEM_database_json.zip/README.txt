STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 303192f26cad8678906b193306f8982c996928463aeb99e46c9914f5ebab9d6e
