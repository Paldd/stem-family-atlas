STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: e2d76c27bec9ac3da5a7725c7d551690cc563b309c332e7b942da01874510d79
