STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 4e3b100c6ae675b063de02d4f1c7f8299669c92d3d576faceb78c9e1160a0edc
