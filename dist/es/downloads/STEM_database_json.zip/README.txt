STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 58e7b07dbcaaf462f659b3d153d51df83a517974c4b829976ca99d9de0474844
