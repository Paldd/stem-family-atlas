STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 0cf92e3b766439059d9b2126d97018e40f1b388f2f9ca36b9b278a448d3e61eb
