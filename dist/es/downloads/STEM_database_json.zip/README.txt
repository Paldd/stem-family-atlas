STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: c7f3e4c38dbde5507368191a6b73fea41a545be9fa6010694c90d144f5ba102a
