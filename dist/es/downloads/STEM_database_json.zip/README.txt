STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: bf2908514668e67bb0674f49bc0913c13321d335583848e4a9fe66f1665d7899
