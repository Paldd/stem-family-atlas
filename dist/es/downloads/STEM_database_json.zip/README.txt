STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: ed6d402aa40a7a479621bc7f9eb787b02c3fff7afdb4cd932507d6462e5e5dbd
