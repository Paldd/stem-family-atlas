STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 5cddafea7ed3c8c824f5f6843c4f5ec69ae5bc3dfc695ce37c312eff01de9250
