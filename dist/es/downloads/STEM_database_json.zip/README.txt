STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 5d4aaa3c56c4d2bf0b4a98c0f191bf6793d2fa1890eb8df9f5c4dcf66a08711b
