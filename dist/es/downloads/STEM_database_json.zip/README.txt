STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 8f008c1a84c7f3d0dfb5dbc58a68dd5c7ec69e2cde2d6df1086d19756252777a
