STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 5ddac7fc8d35956bfc89b650fdc705c90b162dc4ed9b25f28c88e9a8c661969e
