STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: eb874171bc2905ed1d90af90f044be1f0fdaa228a49ea175f4c53e0a1138cb5a
