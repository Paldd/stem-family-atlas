STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 8e6a0309821234a0c4f3d785f44bfba5a37aa8df1893c54ba313dead0c28efbb
