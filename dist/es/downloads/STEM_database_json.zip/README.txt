STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: cf32feb9a838cc510e4cd8526ad8a54358286a7984d19ea995ce0c709feaab65
