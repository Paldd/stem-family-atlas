STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: cd22d2e9a213c4f2d675abf9f38329e89e098334c3754f15e715c4dc7bcabf2c
