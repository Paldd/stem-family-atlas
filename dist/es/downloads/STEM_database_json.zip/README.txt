STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 1b96bff6016da31726cac2935f5128cbb2354072878506164cbcdc1615e1865c
