STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: d003c4ef48cf78fbe0333f87aa3646b0eefb91656612cf0ade82b491f85dcc04
