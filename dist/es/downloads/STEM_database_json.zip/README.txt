STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: ff279b4b85048f958ee201b078c939709adbeb0530c8998c78f7974c9c5734da
