STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 87905d2f43b9d22b4ef6078e3ab7a3bd9a1ed4db59bcc613f96935bfddfeb5dc
