STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 9b6151574b0c1ccca974034e45b34ee75a43f01328f15fbdb8f5de42163d06f9
