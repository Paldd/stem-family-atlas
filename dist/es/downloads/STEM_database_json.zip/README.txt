STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 5c0f793ba2cff764dbd06cd36d11c49fdbc4e6580c2682bb4feec727fc7e8857
