STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 03fa214434cb400cb12b9a310605124eb99a207bece72c5b45ff50d53d0875ee
