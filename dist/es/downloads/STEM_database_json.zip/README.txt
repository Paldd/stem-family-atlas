STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 04aebb5210d0f80b9fd65486f240e9dbb6def3a3e2b1e2cf9d8b6a4dcf6d8dae
