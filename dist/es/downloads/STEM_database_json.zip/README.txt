STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 6440990f6d52b26bfb71bed0472d73a055cd6d755efcdc503e3e3bcf32f7d6d3
