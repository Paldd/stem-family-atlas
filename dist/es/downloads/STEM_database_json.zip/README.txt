STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 6fba26e26ab0bc35005d9f2d4d093e58e132d57ed73f5a7629b293e978d50b49
