STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: d0a1aa6ba824c0e892e89d1a7e9548423e2281adea9857174ce34b68615f2b1b
