STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 0353750b76a0d73cf31c296d6922dfecee74ed1b41cf3ea67a8e26c7f94cd26c
