STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 43ab25bdbc43fbcd92da9acdb3fc2616117884f7af6a74ceb26a772b1d2af4cb
