STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: fa04653c0d6ff6f50ef4beaa5394a2ff20927dd526a22d40ed3ceb261b40b17d
