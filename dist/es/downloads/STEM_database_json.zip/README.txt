STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: d7f2fa7590a913e657f90c5e7c08b80e1f39bfbcfb10b6bc6e5f72b0814b3796
