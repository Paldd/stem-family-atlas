STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 8281fe6761f9a23d80b6cd96017b668c8e1a96fa17a9d290923b5a51c2a02f90
