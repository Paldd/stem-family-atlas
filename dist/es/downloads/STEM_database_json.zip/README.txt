STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 0b637789b3296baf41f30beaecce4b1041f491fbeed87fa715f3c081a012b919
