STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 9f736552cf84ee0ddd771c9b99902e804b4b895970805f4a062a4a9182e8d14b
