STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 155f3ff9121248838b42e53b39d2c9b764e9ede025698fe9a98450d65214eaf0
