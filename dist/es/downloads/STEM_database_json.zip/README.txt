STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 42a5d4ee4de8ae5d7af8084071ad96642a15d1eeaec117fe04451468cd6583be
