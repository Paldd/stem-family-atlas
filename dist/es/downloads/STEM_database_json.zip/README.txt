STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 6deb3186a0e6dcb7fb2953849efc2e71e15b626140be6d3d07e63b6ddd3c9841
