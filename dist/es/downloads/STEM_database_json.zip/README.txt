STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 59a36c1018e22b183efd37f9ad0929a6fb573046fbfd3cab4f051b51c6dc1709
