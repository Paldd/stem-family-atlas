STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 9d7364359507f084349e930b9b5aa98d51d06afdbd9ccdadd7104c7acb561a38
