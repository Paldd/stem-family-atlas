STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 30ff3d1b2d28fdb754593406a29535dd8c23e1d2f0d64c68d15dcd3ad8a25d0c
