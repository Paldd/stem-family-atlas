STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 799636d461792fb37dab63aa97a150ff6357eb90a737e925a68b6629c560a683
