STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 181aeb63deb6a33f6062dacd5a677b6e1145df6f8d96d86cdbc8bc039b0574ea
