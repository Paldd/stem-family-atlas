STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: a815cb74fe343e5d414d90320a1b49cc7723bbdd765a092c220eccf348de6a3e
