STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: b3f6f0f7fdc6bd4ca90ce5b33aa49ebeb739b53100d20ed6eddcd8fb3fc9e867
