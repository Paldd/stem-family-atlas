STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 3919cfd930d953ae19a24edda39e9f6f5a8631dbff4571bfc923d48d8e25e2fc
