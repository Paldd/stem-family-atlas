STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: fd066f9026b84ad1a07d2c27402d954b08baf1a6e1e3c03df88dc97498e73d2d
