STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: f7669fd26a4169a8d1eaf251e90044a2cda325dd06c2e87f99b062b19f4850d2
