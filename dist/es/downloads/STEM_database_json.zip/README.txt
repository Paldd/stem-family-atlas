STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 02cddb580dc21af925617ced6a00df25845d0273dd5080108ef83833dac0735b
