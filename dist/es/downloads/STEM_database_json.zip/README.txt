STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: ed55e4a21bed01205bed0960be0fdbe4ab8060a32dbe492c7174615c7992dca0
