STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: bb76f230d630d687cf3bfdfc85508e20287141245769f2e21b10f8b7dde6c8ad
