STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 22388d306204eaaf3492742f75fb5609e18858dac8ee17d14dbe4980e2739db9
