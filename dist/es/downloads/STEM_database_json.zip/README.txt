STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 3a57d69177ff60c9ebe032435a135970f6d7fe9ff33c39911722210d9f8fda43
