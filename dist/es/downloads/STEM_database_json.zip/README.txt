STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 8ccc68f9b58aa87a1eebc2c6539f51c36fe9e03ec4662544b7ae2bff2a1611be
