STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 80b7c1c9d498b411957e5546141ecd43448304812149c5e290c895f6f0963a3d
