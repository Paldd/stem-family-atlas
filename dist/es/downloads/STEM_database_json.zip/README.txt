STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 3c615fe8c7f4a82cfc2fc0c4f59a142c2580a3ec79ded8bfa0b160f97a618f55
