STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 86d9466211effdd14a49ea7e942aa2ef91ea9b33c510f870277670a546400a05
