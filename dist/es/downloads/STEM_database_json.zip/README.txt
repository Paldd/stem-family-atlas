STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 650c30c6877ab4e4f65fab67056d65186fc2489a792d95d7da3876224ca679e6
