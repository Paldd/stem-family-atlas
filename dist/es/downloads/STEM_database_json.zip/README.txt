STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 55eb30822a3e1209d0096dd812fe8a63fd3c361433d749b2e0c5ffc835c41ccc
