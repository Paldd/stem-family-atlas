STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: d30e1fd84d811692f912144c1aedf2653d236615088ce06834edf935262eacc9
