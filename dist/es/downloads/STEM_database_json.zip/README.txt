STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 6848e4dd7e54159ba0064e7b142917410442bb219e72a93e544fbdd4b0908a6a
