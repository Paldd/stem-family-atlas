STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 18aeafa384dcdaa8df921a55392a9511110baf896955b09f862de7a42e27090b
