STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 87bfb1950eefd461691c35003ad91a1cc2c0216bc8c2b376fd1efd6d0cf1f0fb
