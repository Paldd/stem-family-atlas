STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 7db3fbe0ac118112a7dbe71ba055e435c8427a1eb7d17a7959f35e2bdd1ebfea
