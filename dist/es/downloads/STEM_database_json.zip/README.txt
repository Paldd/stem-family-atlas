STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 3f58f279bd9b557da17284c5b917ed277f4fc8ee09bc35f10724a560f60c7817
