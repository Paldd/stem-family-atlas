STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 4ea96e801e3ef5f936e472a80b577b56403c09eaf5c4a77d0ca0e6a2af21e1f8
