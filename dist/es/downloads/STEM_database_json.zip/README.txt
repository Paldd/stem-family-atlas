STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 34f4f198412e71ecd9c48f39bad8ce1642336e87a05914d0550b2c3b84d99f56
