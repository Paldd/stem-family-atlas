STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: a031577fd8914b4bd1ebecd457aad88bdb89ad979a6adb52020894bdfdfb6738
