STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 161208f3d48a40e178160514d5faf8391e17f4ed073638065a428e7641f60f0b
