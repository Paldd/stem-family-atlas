STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 9b7a21b482e1c618b82716ce678440048f59e9b3c65fa11994be3c50dc352a55
