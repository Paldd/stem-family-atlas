STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 2fd3e59abe285d9afcc4505bbb7002e5e51d3634ee062993494b04f68bb44422
