STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: fdb5efa769b49c4fa93cd62ba43167716c9050b650e1ee2e91e4a3575a5ee3ab
