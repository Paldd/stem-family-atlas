STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: dbd384f019d206700e9afa1782f3cdf5b52074512512c0597cc601519760ae2c
