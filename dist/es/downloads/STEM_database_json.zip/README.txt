STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: c5bc233e1374840e4cedeb2ef082aee7aea0a9cfb0ed64ff661b864ff791f1e8
