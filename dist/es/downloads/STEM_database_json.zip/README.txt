STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: b7e4dffb5f364f8580dd5f9274db3b77ed106198b82ea8588574b6156c38388e
