STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 8ef8794a9074a86b22c492403f0a16e4b38427f79985b085d574ab8b29b418f6
