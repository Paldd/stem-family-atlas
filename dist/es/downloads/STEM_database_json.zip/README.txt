STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: b866821e10f098f8668cb6b441cf71f5b6bc563d869e605cc92cb18d8921e6c3
