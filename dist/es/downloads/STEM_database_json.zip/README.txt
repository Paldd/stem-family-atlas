STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: aa8a8c38d0ffc353bca01aca2b2b19f5e0b765a3876da01b70253c0eb47c9cb1
