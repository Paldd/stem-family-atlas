STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 17425a8df2d5bf7d66a088befcb3d43e021d180794f52365b980bafef476b66d
