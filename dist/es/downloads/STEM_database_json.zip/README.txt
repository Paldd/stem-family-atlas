STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: e11006da4ec87629f39a3af958481022bd90f54fc5d3abfc2bd0bd1d122afdad
