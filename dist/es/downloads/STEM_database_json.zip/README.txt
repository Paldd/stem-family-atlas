STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: bce7e9ac1ca8fbc276208f7816cb78c952c5b745a65921d2fed031d5962b7405
