STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 2aba87444c5f75c24b63ff4362f39f098634cafe0f823f0158e6ffd0eef1f68b
