STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 7bc265cb5ea32d96c6ad2eda1c61ae64d32b6a35e857370b80e8717677d973a5
