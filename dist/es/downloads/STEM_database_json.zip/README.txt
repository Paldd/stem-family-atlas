STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 84357323165e54ad2eb87a796f27a5f83bc37a51a266ebefccd13c145a84604b
