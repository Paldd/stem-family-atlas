STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 627556d561831d33fac61e039370e8de5acce44c130a8c5f412e3cc53b6a826c
