STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: a9a54cdd1d455e7be8f2f88e0dff0aeead6ad29922c891697f2da163c1a1e314
