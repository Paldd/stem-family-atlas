STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 9f46665786937ae0c6b75e51e84a0a3f60a20a96c61c688f791f92ee0c21b570
