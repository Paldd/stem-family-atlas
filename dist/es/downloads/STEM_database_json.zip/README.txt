STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 72776bde4ea3aac772a9885d1217ee246c85182cbe732143684880becfd12efc
