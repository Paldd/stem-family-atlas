STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 355ea91ed306b788297a9a10dc14eee078a347d82604b0906d670ebf39be4033
