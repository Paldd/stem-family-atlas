STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 741dd1be93f82befe3f8fb6fd95a5a892017ec9120711e1b479af0360d24d597
