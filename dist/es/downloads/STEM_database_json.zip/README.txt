STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: cc8c26ba2b422e6011f54d76af42534529134f8a3463b070936995d9eab00ae3
