STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 66d17cc3e14a686512e68192d9c56c1dd379161b6452fe23431b413437e101ed
