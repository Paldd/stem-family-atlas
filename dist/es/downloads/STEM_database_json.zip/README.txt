STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 4a02f0de4eb78997069b78e693618f6fce33ea9ee3d643428d8beba8bdd9cabe
