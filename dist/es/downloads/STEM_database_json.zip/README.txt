STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 7f8246aa73b046294ec0bdb030d7f164bcc6d81ccd9988093976c5993287221c
