STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: aef95a7c1b5349de5a209b47700ea2032053b62d7058ca271bf06dec8dafdf7a
