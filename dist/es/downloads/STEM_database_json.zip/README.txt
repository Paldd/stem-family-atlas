STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 1b61a6ed4ff9c506eab03d38c5d374aeeedc076b124ad38be51d922fda1482bd
