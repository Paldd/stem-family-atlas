STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 5063a5d10af85f9c06aa475cc3300e3432e10b685294aa2b30c3ae31851041e4
