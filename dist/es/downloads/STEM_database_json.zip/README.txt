STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 052cbd3698e3ec1868601bd45cd66104a4b1bdad8483af319b393d92b40ef210
