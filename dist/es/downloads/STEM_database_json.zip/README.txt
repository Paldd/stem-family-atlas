STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 08ba263b3c84d290f72a1df101a601bc6c6ae258f777ac943728050971c90291
