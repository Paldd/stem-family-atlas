STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: def17ef0ca27d29184e98952d86a8f37a9854e73ee9db1b910f048111f0519c9
