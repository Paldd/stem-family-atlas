STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 8c6d33daf8d00205e789764fa69c00a5433354604d4bbcc375f13ab9f26c8853
