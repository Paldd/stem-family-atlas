STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 564ff610471324b4af79286f117900c21a425189fb671a2acd6f74b0606c0f74
