STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 346c840776624f7df98229c41f3a029d20d6171271f3f0a8ee0004e7f1f459f3
