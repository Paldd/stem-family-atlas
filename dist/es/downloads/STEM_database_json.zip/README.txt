STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 05d2454d91bab31fe9a1f4f553c3b37b574c0f2879bcb96858a08e046a85085b
