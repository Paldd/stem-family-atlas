STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 52c9e2014b5a238f1382d4872099e3e0cb91e65df26980d0a2e35772b54a5028
