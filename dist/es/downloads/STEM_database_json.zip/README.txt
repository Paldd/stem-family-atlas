STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 6a7759d64feab34fdeb094d032a0b7ed61f19044e27d90b1b9fc538431f911f1
