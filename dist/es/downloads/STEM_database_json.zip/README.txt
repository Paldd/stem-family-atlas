STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 93bc3e8870f7df9418cde708246ad9fafc5e85d744d3e9e07d846166b2706d25
