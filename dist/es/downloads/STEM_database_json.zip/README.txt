STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 328a4cd893daaf90b62cabc94978243f7019f213e64ddd4cf5cea52db0772559
