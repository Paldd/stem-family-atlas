STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: a18e70a626fb3f1f72d8a027af0d19af75ddf61d1b2bfeb38ad0378afca9e8c9
