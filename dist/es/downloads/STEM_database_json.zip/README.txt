STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: ba0232c31247ec0fccf079e0e657431cae725faa2a0bf57891188a243af4b2bb
