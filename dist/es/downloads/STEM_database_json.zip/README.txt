STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: bf9753f9a29a04f1cca2d788627d29532c490e1954036ef6cc08119910b69989
