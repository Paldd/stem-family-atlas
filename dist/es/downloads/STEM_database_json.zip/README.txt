STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: f507bbc50a4be9b78a36ee5d6344fdc624b75c72acbf05be60d31d8e787636d4
