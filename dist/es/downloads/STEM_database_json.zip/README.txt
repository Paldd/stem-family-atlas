STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: ed962bc9472e54ddeefcee0332c6db8df4243e4a96ee505600b031d059196436
