STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 2605c6edeb1426d1d56b80c79d5750fd346cb02bb7594522d218f8f830b500de
