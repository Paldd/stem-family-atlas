STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: cd186490b0407fd0cf5859731df16a7de61eff022dccd57c99600eca94b1701d
