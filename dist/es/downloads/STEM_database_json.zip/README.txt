STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 86c2709171ceb944c3c93d9a4d5268c7229b220bfe92033e1e3bcd3a0b2527d9
