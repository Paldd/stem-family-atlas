STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: e33481e6efe135eca2c25ac1cecbbb6aee800fa88eacd543e794de25afa3302b
