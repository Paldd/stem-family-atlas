STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 5ff86f927086cd7d22abf0ad382f111b323c6dff3d2692132fe53f791f3180c9
