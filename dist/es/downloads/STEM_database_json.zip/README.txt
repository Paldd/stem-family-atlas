STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: f51c450c7ee32693a09f9a9ba75fe78c60a382e212719b197bfd5052cf4054fe
