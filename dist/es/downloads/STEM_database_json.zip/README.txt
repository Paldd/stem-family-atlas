STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: d4af8c9aef5021eac3fdda9146746d26aafab190b6851df61326671f67d140b0
