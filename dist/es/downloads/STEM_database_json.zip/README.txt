STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 409bdc5aab7203d3cf1b1a5df1342fd471e2f6d9f949250eba6496f7e715f1b5
