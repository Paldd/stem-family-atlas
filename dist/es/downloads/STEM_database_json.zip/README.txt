STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 91bd61c02809311fb3b89529013e5848b1fc93ba8836fab310f2c4746ad20735
