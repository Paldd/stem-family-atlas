STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 5f6c65461455449f74641f129642d3000afce7cca11de5a1137fc249e3a26795
