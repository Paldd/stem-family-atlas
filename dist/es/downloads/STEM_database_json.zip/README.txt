STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: d75ef737e5f2b5578695747e71d89170c08f155d429c7e75897eb3e4759da1cb
