STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 688c3fe46683af6117b6da30f147ace23721b0bb96ff0d3ffa35869f3e3ba904
