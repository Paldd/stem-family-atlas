STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 2e91fcb47771b842588573f578d24ca8161854be1b3964925d6d15c7c094aa05
