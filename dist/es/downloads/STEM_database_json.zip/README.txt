STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 632fe214c45a191ee26187a2cf2449ecbb5152f38e6c3864d0b1887c2c2ea8be
