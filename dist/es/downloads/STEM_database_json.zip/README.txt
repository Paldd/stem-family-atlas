STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 9541fccc04067247b9127a9fc489d73593b6197d3072c32b2d7c841ee37f1cfb
