STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 8a4ad2e7b16ab764cb0444d97e852666dde4a33bed47a59da569561d3e014804
