STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 5759995978cebf7ba146a66d66e451a50f723d44a671109e1da6bc8f4093ca09
