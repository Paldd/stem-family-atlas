STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: ad934f4d1ca492eb63b68ac25f1cadb4c1e21fa23e852af32c2ef3eafd87cf5e
