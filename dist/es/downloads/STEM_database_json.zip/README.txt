STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: bb0eb77d2f71fe81a83ea0a58903187ded4c6f63f6e5e2d7273ecb4fe5e188c8
