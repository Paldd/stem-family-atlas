STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 501d55a3eb899e1d21165927445b79df6bc28ec26cf487ce480b321071c0402f
