STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 3d51b24afa4f8d453fbeef36e6db798b68a745f6ad7a7c1f73df5206a9537367
