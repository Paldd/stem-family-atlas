STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 6177b739dcb3496999413f9835c56cf21290d147823106e2d41e664e9d1ea277
