STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 51ac87007f8660571eccace2647e9ab071914b8be95dc2093ea3b15eb3fba3e6
