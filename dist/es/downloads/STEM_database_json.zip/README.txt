STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 86f83e6066aae697f41416c6a41b1cb817e32d3e35c6cef4278331aa2912a5c2
