STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 0ba811e6d6a868bb026b61d6a1293ca9517dfb0c70e9ce1aaa2ef47fdd33cd89
