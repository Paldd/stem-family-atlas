STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 0a2338b152f69d722afe69f8e647955ed415b81053bf0ad0dac51eeb61c408e6
