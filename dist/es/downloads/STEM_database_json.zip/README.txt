STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: d427f681c6d7f49bd4e7219a14917a3b6f154c2595702146091d5625949756a6
