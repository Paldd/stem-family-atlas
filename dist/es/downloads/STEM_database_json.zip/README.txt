STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 5f5e3ca41b9f7d1ee88866571586b97a43c64c7964669cf5b855624ffe151bef
