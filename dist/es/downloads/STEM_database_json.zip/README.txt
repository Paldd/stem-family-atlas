STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 1a219bade493c4847cc24677b0d7685accfe50dbc988e05ad1e0dc2e3942a882
