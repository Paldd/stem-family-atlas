STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 77221553418360130127479cfed95e885e9bb6996de230b9675cd7953438d75a
