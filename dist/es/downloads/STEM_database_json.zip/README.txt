STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 6ec62252f8868c4c14973b1151ff47330ec48ec8b11e8c433a8de5fc8c081407
