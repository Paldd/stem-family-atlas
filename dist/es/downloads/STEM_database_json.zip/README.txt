STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 36af1ec4ef37ef95baacd2d0b131e736eab67801bc4bff7eb1e2ed190e3421e9
