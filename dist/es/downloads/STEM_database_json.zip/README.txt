STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 32be971d85428db29eb5a238ac3885e5adeca09c217b06c197714c63da33cc8f
