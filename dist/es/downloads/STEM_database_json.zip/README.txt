STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 3e588274a439c3ce4b3b48f4ea78bb55a55113a3275e353610d39d7a19ff431c
