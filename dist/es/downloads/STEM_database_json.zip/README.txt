STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 423a27fad33bc0ae838ebb8dab7d11e7a1c9f7d18650c3a89fa664599615254d
