STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 3db1a2c696341fa40fc9026843841277e3a1787ca9d328745d1605500395f35c
