STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 425f0ce86abfead6048008f420bea151c83c8b798c0acab03d2f605784891feb
