STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 558396be651447c0c77700082e01ddee01a71048d6716a092d6c19737ef62750
