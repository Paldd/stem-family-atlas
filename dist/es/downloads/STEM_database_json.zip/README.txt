STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 328cacc23027d88f5379c98747b75a3ea39a2c48b5b3c86ee0f8c4e182eb4613
