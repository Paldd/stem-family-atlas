STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 541d45f1450d80b3ac97adfbbb8766a1e164bf88470faa86c1f32695c3c50ef5
