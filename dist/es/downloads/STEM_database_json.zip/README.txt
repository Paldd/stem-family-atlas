STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 27886185c046618c0f127fc6c366b148605854ae4c3993bba6b484dae5023e8c
