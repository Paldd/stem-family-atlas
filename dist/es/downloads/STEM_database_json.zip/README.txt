STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 2103bf7f0e7c0dca0da87d571722400d3fc289de5bd98c5e2603a45f2247a6b7
