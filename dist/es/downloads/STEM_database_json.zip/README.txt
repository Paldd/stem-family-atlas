STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 4812300cf2e63f2609e788bc2c81ff454e112ae83dc1c919be5b2319a412f441
