STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 85cf7ec820e7c71dd79a483629373c993f09ed4190a9d48cb0fcf8b5b8c87eb5
