STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: d607ffc19486377e3c77888fccc053cd4c83212c2a59f3ef18b697d7b1bb1f6f
