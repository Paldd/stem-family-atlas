STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 3a679110b9984d068ca5506cf023e4183add4007fcdcf86c136ca0bb61956e20
