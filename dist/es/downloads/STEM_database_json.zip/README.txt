STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 300025f579da239ded5a665dd679333626c7d960338eed45555dfa0aa10d2620
