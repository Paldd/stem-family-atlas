STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 96400cd049eafea60c02a4770b8cc178dd9e3fed195b6c895fac8e74b659b1ba
