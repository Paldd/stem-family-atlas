STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: edd9537b23cb6ba879d9a103cd5ece8cd9a0d7e5b08ae635b0e72820b1af20d0
