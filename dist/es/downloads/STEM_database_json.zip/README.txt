STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 7ca0cb256563c55c589de4e4ac3da193d86b64af7bad8f8ea021586abd02e34d
