STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 312b66a4316a43690f9de4b42e1348f16de14408891f6424532f61f78e86cffa
