STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 4368f6098b33ffdb5235b4092e48f572e476ff101b1c9a2fa22b9bc673fb5e3f
