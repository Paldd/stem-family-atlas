STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 11b850c60702ba168fcb9e3e2136bef7db7a16b9a1e007a710bb597adae616fb
