STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 2f8c0b8b4aabec8b38e5c01ed50ce3718f476a58bf8371effd2530407b2bb37a
