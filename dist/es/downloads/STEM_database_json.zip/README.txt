STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: d3ad762770ce1ddbc5adf8cb24afc6b0f6d7d12abf143a3765388ef4f55a8126
