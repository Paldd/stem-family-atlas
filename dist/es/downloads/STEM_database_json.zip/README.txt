STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 2f5899c2ebe8748de21f0fa6f5c8c659d516c90d1b21f99eea00051170df8f97
