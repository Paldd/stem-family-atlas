STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: bc5f9b1ece73189c254c14d10e409a43f2241fbae6eb3f6c43ff58e3ed9e59a3
