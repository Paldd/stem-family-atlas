STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 2819b22862eaf6f9d375993ff292dee020d7b5e4abba4f121e2f564e7147f225
