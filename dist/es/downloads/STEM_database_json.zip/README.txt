STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: e459c9b673180656c82bf3463c623f0136c92bba4241b20ed89d36ba502d96b2
