STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 44920f2d3ed6ee4d44362f2d7921c3de3f6616ecdeabad10146dff1620869333
