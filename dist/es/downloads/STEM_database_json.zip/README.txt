STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: f533d99b392b8d7c168e30e2c71707c66b35258d383e1908ceb499561a33c8a5
