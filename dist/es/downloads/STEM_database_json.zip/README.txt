STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: d5f88005dcd5ce7b51a92416fefd633696f3c4840cac897ccef36fee7b36612d
