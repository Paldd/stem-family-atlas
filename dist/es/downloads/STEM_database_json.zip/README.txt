STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 352be3a505a7de8a2f36f117f03dec767d86ccfe2fd868a8efebb34f5e30a486
