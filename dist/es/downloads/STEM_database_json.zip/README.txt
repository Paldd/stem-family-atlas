STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 3665a216d6ea9b82f5de4a071fd6c62b1b424bcc6a82c1eadfdefc665d04a595
