STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: aeca0e2c983ea3df6ac9e517222860f8a203217741e2f6cdfed0b17fb19ed2e7
