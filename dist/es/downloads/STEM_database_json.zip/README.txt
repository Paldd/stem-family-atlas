STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 0de08af8331e1f725fbcc1596fce13fcb118981d985f34cb38b45ff99c33189c
