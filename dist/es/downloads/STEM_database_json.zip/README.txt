STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 559b37ad8c3f6ef176ed06b51dec528114bf607d0e47c15d0b3dd3ed71451e27
