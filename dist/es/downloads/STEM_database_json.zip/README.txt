STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 6eac7837106d0e9542cb40bd39214e09c695743505ce7bd30af3f9e4fe890e51
