STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 62352ff15088fd69fb605a43998452d7bd26d8e648a917825abf899a6c3c1ba8
