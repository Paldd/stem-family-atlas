STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: ef04fbfae664397c90ad46b66f5765c3d650b970eefa706fef148440f33d5423
