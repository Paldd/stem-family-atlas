STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 9d28e9d94795243d584c41aace3fd6d7d5966a5ecf1a8c3262c5c3baf80ea15e
