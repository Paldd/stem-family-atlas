STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: d4cf2d1d1884b35e6c79342523f4cde8908ca3a55b1db3709d3dc4c4be48e35b
