STEM Family Atlas — base JSON completa en español
Extraiga STEM_database.json: contiene todos los registros y fuentes.
La compresión conserva todos los datos. SHA-256 JSON: 64dbf9a7c88e8b86f42ef912b0c93eef4ce03935c8633221b0c2ac708a222d42
